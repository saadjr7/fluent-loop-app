import { SITUATIONS, SITUATION_MAP, TOTAL_SENTENCES, targetText } from "./data.js";
import { Store, todayKey, sentenceKey } from "./storage.js";
import { Player, getVoices, PronunciationCheck, pronunciationSupported, scorePronunciation } from "./speech.js";
import { requestNotifPermission, startReminderLoop, stopReminderLoop } from "./notifications.js";
import { renderHeader, renderHome, renderSituation, renderPlayerFull, renderSettings, renderProgress, renderMiniPlayer, renderCustomManager, renderQuiz, renderWordOrder, renderListenChallenge, PLANS } from "./render.js";

// ---------- defaults ----------
const DEFAULT_SETTINGS = {
  plan: "medium",
  customDaily: 15,
  enRepeat: 3,
  arRepeat: 1,
  rate: 0.92,
  gapSeconds: 1.2,
  startLang: "en",
  shuffle: false,
  hideText: false,
  theme: "dark",
  prioritizeWeak: false,
  enVoiceURI: "local:aoede",
  arVoiceURI: null,
  frVoiceURI: null,
  deVoiceURI: null,
  esVoiceURI: null,
  targetLang: "en", // "en" | "fr" | "de" | "es" — which language the person is learning
  notifEnabled: false,
  notifSlots: {
    morning: { on: true, time: "09:00" },
    afternoon: { on: false, time: "15:00" },
    evening: { on: true, time: "20:30" },
  },
};

function loadSettings() {
  const saved = Store.loadSettings();
  return { ...DEFAULT_SETTINGS, ...(saved || {}), notifSlots: { ...DEFAULT_SETTINGS.notifSlots, ...(saved?.notifSlots || {}) } };
}

// ---------- state ----------
const st = {
  view: "home",
  activeSitId: null,
  idx: 0,
  revealed: false,
  showAllSentences: false,

  settings: loadSettings(),
  dailyCount: Store.loadDaily().count,
  streak: Store.loadStreak().count,
  visits: Store.loadVisits().count,
  totalTrained: Store.loadTotalTrained(),
  progress: Store.loadProgress(),
  history: Store.loadHistory(),

  sessionSource: "all",
  sourcePickerOpen: false,
  selectionType: "sequential",
  rangeFrom: 1,
  rangeTo: 10,
  manualSelected: new Set(),
  sessionCount: 10,
  resumeMode: false,
  favorites: new Set(Store.loadFavorites()),
  notes: Store.loadNotes(),
  custom: Store.loadCustom(),
  quiz: null,
  wordOrder: null,
  listen: null,
  pron: null, // { listening, result: {score, tokens} | null, error }
  customDraftEn: "",
  customDraftAr: "",

  voicesReady: false,
  toast: null,
  playerSnap: { queue: [], pos: 0, state: "idle", repeatLabel: "", highlight: null, repeatMode: "all" },
};

function persist() {
  Store.saveSettings(st.settings);
}

// ---------- render loop (coalesced via rAF) ----------
let renderScheduled = false;
function render() {
  if (renderScheduled) return;
  renderScheduled = true;
  requestAnimationFrame(() => {
    renderScheduled = false;
    doRender();
  });
}
function doRender() {
  const app = document.getElementById("app");
  document.documentElement.classList.toggle("theme-light", st.settings.theme === "light");
  const hasMini = st.playerSnap.queue.length > 0 && st.view !== "player" && st.view !== "listen";
  app.classList.toggle("has-mini", hasMini);

  // Preserve focus + cursor + scroll across the innerHTML replace below, so typing
  // in a number field (e.g. range "من/إلى") doesn't get kicked out after every digit.
  const active = document.activeElement;
  let focusInfo = null;
  if (active && app.contains(active) && active.dataset && active.dataset.action) {
    focusInfo = {
      selector: `[data-action="${active.dataset.action}"]` +
        (active.dataset.which ? `[data-which="${active.dataset.which}"]` : "") +
        (active.dataset.field ? `[data-field="${active.dataset.field}"]` : "") +
        (active.dataset.slot ? `[data-slot="${active.dataset.slot}"]` : "") +
        (active.dataset.key ? `[data-key="${active.dataset.key}"]` : ""),
      selStart: (typeof active.selectionStart === "number") ? active.selectionStart : null,
      selEnd: (typeof active.selectionEnd === "number") ? active.selectionEnd : null,
    };
  }
  const scrollY = window.scrollY;

  let body = "";
  if (st.view === "settings") body = renderSettings(st);
  else if (st.view === "situation") body = renderSituation(st);
  else if (st.view === "player") body = renderPlayerFull(st);
  else if (st.view === "progress") body = renderProgress(st);
  else if (st.view === "custom") body = renderCustomManager(st);
  else if (st.view === "quiz") body = renderQuiz(st);
  else if (st.view === "wordorder") body = renderWordOrder(st);
  else if (st.view === "listen") body = renderListenChallenge(st);
  else body = renderHome(st);

  app.innerHTML = `
    ${renderHeader(st)}
    <div class="fl-body">${body}</div>
    ${renderMiniPlayer(st)}
    ${st.toast ? `<div class="toast">${st.toast}</div>` : ""}
  `;

  if (focusInfo) {
    const el = app.querySelector(focusInfo.selector);
    if (el) {
      el.focus({ preventScroll: true });
      if (focusInfo.selStart != null && typeof el.setSelectionRange === "function") {
        try { el.setSelectionRange(focusInfo.selStart, focusInfo.selEnd); } catch (e) {}
      }
      window.scrollTo(0, scrollY);
    }
  }
}

function showToast(msg, ms = 2200) {
  st.toast = msg;
  render();
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => { st.toast = null; render(); }, ms);
}

// Plays only the English audio for the current "listening challenge" item,
// with no text shown — used by the dedicated listen-only mode (separate
// from the general "hide text" playback setting).
function listenPlayCurrent() {
  const lst = st.listen;
  if (!lst) return;
  const cur = lst.items[lst.pos];
  if (!cur) return;
  // Blank out the Arabic slot only — audio-only listening challenge, no
  // translation shown or spoken; keep both en/fr slots intact so playback
  // still honors whichever target language is currently selected.
  Player.playSingle({ situationId: cur.situationId, idx: cur.idx, sentence: [cur.sentence[0], "", cur.sentence[2]], title: cur.title });
}

// ---------- content helpers ----------
function sourceList(sourceId) {
  if (sourceId === "favorites") {
    const out = [];
    SITUATIONS.forEach(sit => sit.sentences.forEach((s, i) => {
      if (st.favorites.has(sit.id + ":" + i)) out.push({ situationId: sit.id, idx: i, sentence: s, title: sit.title });
    }));
    return out;
  }
  if (sourceId === "weak") {
    const out = [];
    SITUATIONS.forEach(sit => sit.sentences.forEach((s, i) => {
      if (st.progress[sentenceKey(sit.id, i)]?.status === "practice") out.push({ situationId: sit.id, idx: i, sentence: s, title: sit.title });
    }));
    return out;
  }
  if (sourceId === "custom") {
    return st.custom.map((c, i) => ({ situationId: "custom", idx: i, sentence: [c.en, c.ar], title: "جملي الخاصة" }));
  }
  if (sourceId === "all") {
    const out = [];
    SITUATIONS.forEach(sit => sit.sentences.forEach((s, i) => out.push({ situationId: sit.id, idx: i, sentence: s, title: sit.title })));
    return out;
  }
  const sit = SITUATION_MAP[sourceId];
  if (!sit) return [];
  return sit.sentences.map((s, i) => ({ situationId: sit.id, idx: i, sentence: s, title: sit.title }));
}
function shuffleArr(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
// Light-weight "smart review" ordering: when enabled, sentences marked "أحتاج
// تدريب" are moved to the front of the deck (still de-duplicated, nothing
// dropped) so weak spots surface more often without a full SRS scheduler.
function prioritizeWeakFirst(list) {
  const weak = [], rest = [];
  list.forEach(item => {
    const st_ = st.progress[sentenceKey(item.situationId, item.idx)]?.status;
    (st_ === "practice" ? weak : rest).push(item);
  });
  return weak.concat(rest);
}
function buildSelectedQueue() {
  const list = sourceList(st.sessionSource);
  let out;
  if (st.selectionType === "range") {
    const rf = Number(st.rangeFrom) || 1;
    const rt = Number(st.rangeTo) || list.length;
    const from = Math.max(1, Math.min(rf, list.length));
    const to = Math.max(from, Math.min(rt, list.length));
    out = list.slice(from - 1, to);
  } else if (st.selectionType === "manual") {
    out = list.filter(item => st.manualSelected.has(item.situationId + ":" + item.idx));
  } else {
    out = list;
    if (st.selectionType === "sequential" && st.resumeMode && st.sessionSource !== "all") {
      const lastIdx = Store.loadLastIndex(st.sessionSource);
      const startAt = Math.min(Math.max(lastIdx + 1, 0), Math.max(list.length - 1, 0));
      out = list.slice(startAt);
    }
    if (st.settings.prioritizeWeak) out = prioritizeWeakFirst(out);
    if (st.sessionCount !== "all") out = out.slice(0, Number(st.sessionCount));
  }
  if (st.settings.shuffle) out = shuffleArr(out);
  return out;
}

// ---------- progress/daily bookkeeping ----------
function onSentenceComplete() {
  const target = st.settings.plan === "custom" ? Math.max(1, Number(st.settings.customDaily) || 15) : PLANS[st.settings.plan]?.daily || 20;
  st.dailyCount += 1;
  Store.saveDaily(st.dailyCount);
  if (st.dailyCount === target) {
    const streakInfo = Store.loadStreak();
    const key = todayKey();
    if (streakInfo.last !== key) {
      st.streak = streakInfo.count + 1;
      Store.saveStreak({ count: st.streak, last: key });
      showToast(`🔥 وصلت هدف اليوم! سلسلتك الآن ${st.streak} يوم`);
    }
  }
  st.totalTrained += 1;
  Store.saveTotalTrained(st.totalTrained);
  const hk = todayKey();
  st.history[hk] = (st.history[hk] || 0) + 1;
  Store.saveHistory(st.history);
  render();
}

// ---------- player wiring ----------
Player.init(
  () => ({ ...st.settings, onSentenceComplete }),
  (snap) => {
    st.playerSnap = snap;
    const cur = snap.queue[snap.pos];
    if (cur) Store.saveLastIndex(cur.situationId, cur.idx);
    updateMediaSession();
    render();
  }
);

let wakeLock = null;
async function manageWakeLock() {
  try {
    if (st.playerSnap.state === "playing" && "wakeLock" in navigator && !wakeLock) {
      wakeLock = await navigator.wakeLock.request("screen");
      wakeLock.addEventListener("release", () => { wakeLock = null; });
    } else if (st.playerSnap.state !== "playing" && wakeLock) {
      wakeLock.release().catch(() => {});
      wakeLock = null;
    }
  } catch (e) {}
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") manageWakeLock();
});

function updateMediaSession() {
  if (!("mediaSession" in navigator)) return;
  const cur = st.playerSnap.queue[st.playerSnap.pos];
  if (!cur) {
    try { navigator.mediaSession.playbackState = "none"; } catch (e) {}
    return;
  }
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: targetText(cur.sentence, st.settings.targetLang),
      artist: cur.title || "Fluent Loop",
      album: "Fluent Loop — حلقة التدريب",
    });
    navigator.mediaSession.playbackState = st.playerSnap.state === "playing" ? "playing" : "paused";
    navigator.mediaSession.setActionHandler("play", () => Player.resume());
    navigator.mediaSession.setActionHandler("pause", () => Player.pause());
    navigator.mediaSession.setActionHandler("nexttrack", () => Player.next());
    navigator.mediaSession.setActionHandler("previoustrack", () => Player.prev());
  } catch (e) {}
  manageWakeLock();
}

// ---------- actions ----------
const actions = {
  setView(ds) { st.view = ds.view; render(); },

  openSituation(ds) {
    st.activeSitId = ds.sit;
    st.sessionSource = ds.sit;
    st.sourcePickerOpen = false;
    const saved = Store.loadLastIndex(ds.sit);
    const sit = SITUATION_MAP[ds.sit];
    st.idx = (saved >= 0 && sit && saved < sit.sentences.length) ? saved : 0;
    st.revealed = false;
    st.showAllSentences = false;
    st.pron = null;
    st.view = "situation";
    render();
  },
  backHome() { st.view = "home"; render(); },
  reveal() { st.revealed = true; render(); },
  toggleShowAll() { st.showAllSentences = !st.showAllSentences; render(); },
  jumpToIndex(ds) {
    st.idx = Number(ds.idx);
    st.revealed = false;
    st.pron = null;
    Store.saveLastIndex(st.activeSitId, st.idx);
    render();
  },
  playFromList(ds) {
    const sit = SITUATION_MAP[st.activeSitId];
    const i = Number(ds.idx);
    st.idx = i;
    Store.saveLastIndex(st.activeSitId, i);
    render();
    Player.playSingle({ situationId: sit.id, idx: i, sentence: sit.sentences[i], title: sit.title });
  },

  markSentence(ds) {
    const key = sentenceKey(st.activeSitId, st.idx);
    st.progress[key] = { status: ds.status, ts: Date.now() };
    Store.saveProgress(st.progress);
    render();
  },
  toggleFavorite(ds) {
    const key = ds.key || (st.activeSitId + ":" + st.idx);
    if (st.favorites.has(key)) st.favorites.delete(key); else st.favorites.add(key);
    Store.saveFavorites([...st.favorites]);
    render();
  },
  setNote(ds, e) {
    const key = ds.key || (st.activeSitId + ":" + st.idx);
    const val = e.target.value;
    if (val.trim()) st.notes[key] = val; else delete st.notes[key];
    Store.saveNotes(st.notes);
    render();
  },

  // ---- custom (user-added) sentences ----
  setCustomDraft(ds, e) {
    if (ds.field === "en") st.customDraftEn = e.target.value;
    else st.customDraftAr = e.target.value;
  },
  addCustomSentence() {
    const en = st.customDraftEn.trim();
    const ar = st.customDraftAr.trim();
    if (!en || !ar) { showToast("اكتب الجملة بالإنجليزي والعربي عشان تضيفها"); return; }
    st.custom.push({ id: Date.now(), en, ar });
    Store.saveCustom(st.custom);
    st.customDraftEn = "";
    st.customDraftAr = "";
    render();
  },
  deleteCustomSentence(ds) {
    st.custom = st.custom.filter((_, i) => i !== Number(ds.idx));
    Store.saveCustom(st.custom);
    render();
  },
  playCustom(ds) {
    const i = Number(ds.idx);
    const c = st.custom[i];
    if (!c) return;
    Player.playSingle({ situationId: "custom", idx: i, sentence: [c.en, c.ar], title: "جملي الخاصة" });
  },

  // ---- quiz mode (multiple-choice) ----
  startQuiz(ds) {
    if (ds && ds.source) st.sessionSource = ds.source;
    const pool = buildSelectedQueue();
    if (pool.length < 2) { showToast("تحتاج على الأقل جملتين لبدء اختبار 🙂"); return; }
    const allAr = SITUATIONS.flatMap(s => s.sentences.map(x => x[1])).concat(st.custom.map(c => c.ar));
    const questions = shuffleArr(pool).slice(0, Math.min(pool.length, 15)).map(item => {
      const correct = item.sentence[1];
      const distractorsPool = shuffleArr(allAr.filter(a => a !== correct));
      const options = shuffleArr([correct, ...distractorsPool.slice(0, 3)]);
      return { item, correct, options };
    });
    st.quiz = { questions, pos: 0, score: 0, picked: null, done: false };
    st.view = "quiz";
    render();
  },
  quizPick(ds) {
    if (!st.quiz || st.quiz.picked != null) return;
    const q = st.quiz.questions[st.quiz.pos];
    const choice = Number(ds.choice);
    st.quiz.picked = choice;
    if (q.options[choice] === q.correct) st.quiz.score += 1;
    render();
  },
  quizNext() {
    if (!st.quiz) return;
    if (st.quiz.pos + 1 >= st.quiz.questions.length) {
      st.quiz.done = true;
    } else {
      st.quiz.pos += 1;
      st.quiz.picked = null;
    }
    render();
  },
  quizExit() {
    st.quiz = null;
    st.view = "home";
    render();
  },

  // ---- word-order exercise (ترتيب الكلمات) ----
  startWordOrder(ds) {
    if (ds && ds.source) st.sessionSource = ds.source;
    const pool = buildSelectedQueue();
    if (!pool.length) { showToast("اختر جملة وحدة على الأقل عشان تبدأ 🙂"); return; }
    const items = shuffleArr(pool).slice(0, Math.min(pool.length, 10)).map(item => {
      const words = targetText(item.sentence, st.settings.targetLang).split(/\s+/).filter(Boolean);
      return { item, correctWords: words, shuffled: shuffleArr(words.map((w, i) => ({ w, id: i }))) };
    });
    st.wordOrder = { items, pos: 0, built: [], remaining: items[0].shuffled, score: 0, checked: false, correct: null, done: false };
    st.view = "wordorder";
    render();
  },
  woPick(ds) {
    const wo = st.wordOrder;
    if (!wo || wo.checked) return;
    const i = Number(ds.i);
    const word = wo.remaining[i];
    if (!word) return;
    wo.built.push(word);
    wo.remaining = wo.remaining.filter((_, idx) => idx !== i);
    render();
  },
  woUndo() {
    const wo = st.wordOrder;
    if (!wo || wo.checked || !wo.built.length) return;
    wo.remaining.push(wo.built.pop());
    render();
  },
  woCheck() {
    const wo = st.wordOrder;
    if (!wo || wo.checked) return;
    const cur = wo.items[wo.pos];
    const builtStr = wo.built.map(w => w.w.toLowerCase()).join(" ");
    const correctStr = cur.correctWords.map(w => w.toLowerCase()).join(" ");
    wo.correct = builtStr === correctStr;
    if (wo.correct) wo.score += 1;
    wo.checked = true;
    render();
  },
  woNext() {
    const wo = st.wordOrder;
    if (!wo) return;
    if (wo.pos + 1 >= wo.items.length) {
      wo.done = true;
    } else {
      wo.pos += 1;
      wo.built = [];
      wo.remaining = wo.items[wo.pos].shuffled;
      wo.checked = false;
      wo.correct = null;
    }
    render();
  },
  woExit() { st.wordOrder = null; st.view = "home"; render(); },

  // ---- listening-only challenge (تحدي الاستماع) ----
  startListenChallenge(ds) {
    if (ds && ds.source) st.sessionSource = ds.source;
    const pool = buildSelectedQueue();
    if (!pool.length) { showToast("اختر جملة وحدة على الأقل عشان تبدأ 🙂"); return; }
    const items = shuffleArr(pool).slice(0, Math.min(pool.length, 12));
    st.listen = { items, pos: 0, revealed: false, score: 0, answered: false, done: false };
    st.view = "listen";
    render();
    listenPlayCurrent();
  },
  listenReplay() { listenPlayCurrent(); },
  listenReveal() { if (st.listen) { st.listen.revealed = true; render(); } },
  listenSelfMark(ds) {
    const lst = st.listen;
    if (!lst || lst.answered) return;
    lst.answered = true;
    const knew = ds.knew === "1";
    if (knew) lst.score += 1;
    const cur = lst.items[lst.pos];
    st.progress[sentenceKey(cur.situationId, cur.idx)] = { status: knew ? "known" : "practice", ts: Date.now() };
    Store.saveProgress(st.progress);
    render();
  },
  listenNext() {
    const lst = st.listen;
    if (!lst) return;
    if (lst.pos + 1 >= lst.items.length) {
      lst.done = true;
      render();
    } else {
      lst.pos += 1;
      lst.revealed = false;
      lst.answered = false;
      render();
      listenPlayCurrent();
    }
  },
  listenExit() { Player.stop(); st.listen = null; st.view = "home"; render(); },

  // ---- pronunciation check (mic) ----
  async startPronCheck() {
    const sit = SITUATION_MAP[st.activeSitId];
    if (!sit) return;

    if (typeof window !== "undefined" && window.isSecureContext === false) {
      showToast("فحص النطق يحتاج فتح التطبيق عبر رابط https (وليس ملف مفتوح مباشرة)");
      return;
    }
    if (!pronunciationSupported()) {
      showToast("متصفحك لا يدعم التعرف على الصوت — جرّب Chrome على أندرويد أو كمبيوتر (لا يعمل على Safari/آيفون حالياً)");
      return;
    }

    const target = targetText(sit.sentences[st.idx], st.settings.targetLang);
    const recogLang = { en: "en-US", fr: "fr-FR", de: "de-DE", es: "es-ES" }[st.settings.targetLang] || "en-US";
    st.pron = { listening: true, result: null, error: null, heard: false, interim: "" };
    render();

    // Ask for the microphone explicitly first — this surfaces a clear,
    // specific reason (denied / no hardware / blocked by browser policy)
    // instead of SpeechRecognition's vague generic "not-allowed"/"audio-capture".
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // Android blocks the permission dialog itself (not just the mic)
        // whenever a floating overlay window is drawing on top of the
        // screen — chat-heads, screen-recorder bubbles, assistive-touch
        // buttons, etc. When that happens Chrome shows "This site can't
        // ask for your permission" and getUserMedia can hang indefinitely
        // instead of resolving or rejecting. We race it against a timeout
        // so that case doesn't freeze the mic button forever — but the
        // timeout has to be long enough for a *real* permission dialog,
        // which needs you to actually read it and tap Allow (7s was too
        // aggressive and was falsely firing on a normal, slightly slow tap).
        const timeout = new Promise((_, reject) =>
          setTimeout(() => reject({ name: "OverlayBlocked" }), 25000));
        const stream = await Promise.race([
          navigator.mediaDevices.getUserMedia({ audio: true }),
          timeout,
        ]);
        stream.getTracks().forEach(t => t.stop()); // we only needed the permission check
      }
    } catch (err) {
      st.pron.listening = false;
      if (err.name === "OverlayBlocked") {
        st.pron.error = "أخذ طلب إذن الميكروفون وقت طويل بدون رد. إما إن أندرويد يمنع نافذة الإذن بسبب فقاعة/نافذة عائمة من تطبيق آخر فوق الشاشة (أغلقها وحاول ثانية) — أو إنه ببساطة ما ظهرت نافذة إذن (جرّب تفتح الرابط بتبويب Chrome عادي بدل أيقونة التطبيق المثبتة على الشاشة الرئيسية، وتأكد ما فيه نافذة إذن مخفية خلف التطبيق نفسه).";
      } else if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        st.pron.error = "رفضت صلاحية الميكروفون سابقًا. افتح إعدادات الموقع في المتصفح (أيقونة 🔒 بجانب الرابط) → الميكروفون → السماح، ثم أعد المحاولة.";
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        st.pron.error = "ما لقينا ميكروفون متاح على هذا الجهاز.";
      } else if (err.name === "NotReadableError") {
        st.pron.error = "الميكروفون مستخدم من تطبيق آخر حالياً. أغلق التطبيقات الأخرى وحاول ثانية.";
      } else {
        st.pron.error = "تعذّر الوصول للميكروفون (" + err.name + ")";
      }
      render();
      return;
    }

    PronunciationCheck.start(recogLang, {
      onInterim: (text) => {
        // Live proof the mic is working: flips the button label the moment
        // sound is detected, and shows the words-in-progress as they're heard.
        st.pron.heard = true;
        st.pron.interim = text;
        render();
      },
      onResult: (said) => {
        st.pron.result = scorePronunciation(target, said);
        st.pron.interim = "";
        render();
      },
      onError: (err) => {
        st.pron.listening = false;
        st.pron.error =
          err === "not-allowed" ? "رُفض إذن الميكروفون. تحقق من إعدادات الموقع في المتصفح → الميكروفون → السماح." :
          err === "no-speech" ? "ما سمعنا أي صوت خلال المهلة. تأكد إن مستوى صوت الميكروفون بالهاتف مو مكتوم، وتكلم بصوت واضح فور الضغط على الزر مباشرة (بدون سكوت طويل قبلها)." :
          err === "network" ? "فحص النطق يحتاج اتصال إنترنت (نفس تقنية الإملاء الصوتي في لوحة المفاتيح)" :
          err === "audio-capture" ? "ما قدرنا نلتقط صوت من الميكروفون — تأكد أنه غير مستخدم بتطبيق آخر" :
          err === "aborted" ? "" : // user pressed stop — not a real error, no message needed
          "تعذّر تشغيل التعرف على الصوت. جرّب إغلاق التطبيق وفتحه من جديد.";
        if (err === "aborted") st.pron.error = null;
        render();
      },
      onEnd: (gotAnySound) => {
        st.pron.listening = false;
        st.pron.interim = "";
        // If the whole session ended with zero sound ever detected and no
        // error was thrown, the recognizer *did* run — most likely cause is
        // the OS routing audio input elsewhere (Bluetooth headset mic,
        // muted mic toggle, or another app still holding the mic).
        if (!gotAnySound && !st.pron.result && !st.pron.error) {
          st.pron.error = "ما وصل أي صوت للتعرف رغم إن الجلسة اشتغلت. تأكد إن الميكروفون مو مكتوم من إعدادات الهاتف، وإنه ما فيه سماعة بلوتوث متصلة تسحب دخل الصوت بدل ميكروفون الهاتف.";
        }
        render();
      },
    });
  },
  stopPronCheck() {
    PronunciationCheck.stop();
    if (st.pron) { st.pron.listening = false; render(); }
  },
  resetPronCheck() {
    st.pron = null;
    render();
  },

  nextCardInSituation() {
    const sit = SITUATION_MAP[st.activeSitId];
    st.idx = (st.idx + 1) % sit.sentences.length;
    st.revealed = false;
    st.pron = null;
    Store.saveLastIndex(st.activeSitId, st.idx);
    render();
  },
  prevCardInSituation() {
    const sit = SITUATION_MAP[st.activeSitId];
    st.idx = (st.idx - 1 + sit.sentences.length) % sit.sentences.length;
    st.revealed = false;
    st.pron = null;
    Store.saveLastIndex(st.activeSitId, st.idx);
    render();
  },
  customizeThisSituation() {
    st.sessionSource = st.activeSitId;
    st.sourcePickerOpen = false;
    st.selectionType = "range";
    const sit = SITUATION_MAP[st.activeSitId];
    st.rangeFrom = 1;
    st.rangeTo = sit.sentences.length;
    st.view = "home";
    render();
  },

  playSingle() {
    const sit = SITUATION_MAP[st.activeSitId];
    const sent = sit.sentences[st.idx];
    const cur = st.playerSnap.queue[st.playerSnap.pos];
    const isPlayingThis = st.playerSnap.state === "playing" && cur && cur.situationId === sit.id && cur.idx === st.idx && st.playerSnap.queue.length === 1;
    if (isPlayingThis) { Player.stop(); }
    else { Player.playSingle({ situationId: sit.id, idx: st.idx, sentence: sent, title: sit.title }); }
  },
  playSituation(ds) {
    const sitId = ds.sit || st.activeSitId;
    const sit = SITUATION_MAP[sitId];
    let q = sit.sentences.map((s, i) => ({ situationId: sit.id, idx: i, sentence: s, title: sit.title }));
    if (st.settings.shuffle) q = shuffleArr(q);
    st.view = "player";
    render();
    Player.setRepeatMode("all");
    Player.start(q, 0);
  },

  toggleSourcePicker() {
    st.sourcePickerOpen = !st.sourcePickerOpen;
    render();
  },
  selectSource(ds) {
    st.sessionSource = ds.source;
    st.sourcePickerOpen = false;
    st.manualSelected = new Set();
    st.rangeFrom = 1;
    st.rangeTo = Math.min(10, sourceList(st.sessionSource).length);
    render();
  },
  setSelectionType(ds) {
    st.selectionType = ds.sel;
    if (ds.sel === "range") st.rangeTo = Math.min(st.rangeTo || 10, sourceList(st.sessionSource).length);
    render();
  },
  setRange(ds, e) {
    const raw = e.target.value;
    // allow the field to be temporarily empty while typing; clamp only when we
    // actually build the session queue (buildSelectedQueue already clamps).
    const v = raw === "" ? "" : Math.max(0, Number(raw) || 0);
    if (ds.which === "from") st.rangeFrom = v; else st.rangeTo = v;
    render();
  },
  manualToggle(ds) {
    if (st.manualSelected.has(ds.key)) st.manualSelected.delete(ds.key);
    else st.manualSelected.add(ds.key);
    render();
  },
  manualSelectAll() {
    sourceList(st.sessionSource).forEach(item => st.manualSelected.add(item.situationId + ":" + item.idx));
    render();
  },
  manualClearAll() { st.manualSelected = new Set(); render(); },
  setSessionCount(ds) {
    st.sessionCount = ds.count === "all" ? "all" : Number(ds.count);
    render();
  },
  setResumeMode(ds) {
    st.resumeMode = ds.mode === "resume";
    render();
  },
  startSession() {
    const q = buildSelectedQueue();
    if (!q.length) { showToast("اختر جملة وحدة على الأقل عشان تبدأ 🙂"); return; }
    st.view = "player";
    render();
    Player.setRepeatMode("all");
    Player.start(q, 0);
  },
  startSituationSession(ds) {
    st.sessionSource = ds.sit;
    const q = buildSelectedQueue();
    if (!q.length) { showToast("اختر جملة وحدة على الأقل عشان تبدأ 🙂"); return; }
    st.view = "player";
    render();
    Player.setRepeatMode("all");
    Player.start(q, 0);
  },
  startQuickSession(ds) {
    st.sessionSource = ds.source;
    st.sourcePickerOpen = false;
    st.selectionType = "sequential";
    st.sessionCount = "all";
    const q = buildSelectedQueue();
    if (!q.length) {
      showToast(ds.source === "weak" ? "لا توجد جمل بحاجة لمراجعة الآن 👍" : "لم تُضف أي جملة للمفضلة بعد ⭐");
      return;
    }
    st.view = "player";
    render();
    Player.setRepeatMode("all");
    Player.start(q, 0);
  },

  toggleField(ds) {
    const field = ds.field;
    st.settings[field] = !st.settings[field];
    persist();
    if (field === "notifEnabled") {
      if (st.settings[field]) {
        requestNotifPermission().then((perm) => {
          if (perm !== "granted") showToast("فعّل إذن الإشعارات من إعدادات المتصفح للحصول على التذكيرات.");
        });
        startReminderLoop(() => st.settings);
      } else {
        stopReminderLoop();
      }
    }
    render();
  },
  toggleNotifSlot(ds) {
    st.settings.notifSlots[ds.slot].on = !st.settings.notifSlots[ds.slot].on;
    persist();
    render();
  },
  setNotifTime(ds, e) {
    st.settings.notifSlots[ds.slot].time = e.target.value;
    persist();
    render();
  },

  stepper(ds) {
    const field = ds.field;
    const delta = Number(ds.delta);
    const min = Number(ds.min), max = Number(ds.max);
    const step = field === "gapSeconds" ? 0.5 : 1;
    st.settings[field] = Math.max(min, Math.min(max, Math.round(((Number(st.settings[field]) || 0) + delta * step) * 10) / 10));
    persist();
    render();
  },
  setRate(ds, e) {
    st.settings.rate = Number(e.target.value);
    persist();
    if (st.playerSnap.state === "playing") Player.restartWithNewRate();
    render();
  },
  setPlan(ds) { st.settings.plan = ds.plan; persist(); render(); },
  setCustomDaily(ds, e) {
    st.settings.customDaily = Math.max(1, Number(e.target.value) || 1);
    st.settings.plan = "custom";
    persist();
    render();
  },
  setStartLang(ds) { st.settings.startLang = ds.lang; persist(); render(); },
  setTheme(ds) { st.settings.theme = ds.theme; persist(); render(); },
  setVoice(ds, e) {
    // Two call paths: a <select> "change" event (read e.target.value), or a
    // quick preset button click that already carries the target uri in the
    // dataset (data-uri="...").
    const uri = (ds.uri !== undefined ? ds.uri : e.target.value) || null;
    if (ds.kind === "en") st.settings.enVoiceURI = uri;
    else if (ds.kind === "fr") st.settings.frVoiceURI = uri;
    else if (ds.kind === "de") st.settings.deVoiceURI = uri;
    else if (ds.kind === "es") st.settings.esVoiceURI = uri;
    else st.settings.arVoiceURI = uri;
    persist();
    render();
  },
  setTargetLang(ds) {
    st.settings.targetLang = ["fr", "de", "es"].includes(ds.lang) ? ds.lang : "en";
    persist();
    render();
  },

  cycleRepeatMode() { Player.toggleRepeatMode(); },
  confirmReset() {
    if (window.confirm("متأكد؟ هذا بيمسح كل تقدمك وإحصائياتك ولا يمكن التراجع.")) {
      Store.resetAll();
      location.reload();
    }
  },
  exportBackup() {
    const payload = Store.exportAll();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const d = new Date();
    const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    a.href = url;
    a.download = `fluent-loop-backup-${stamp}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    showToast("تم تصدير النسخة الاحتياطية ⬇️");
  },
  importBackupFile(ds, e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const payload = JSON.parse(reader.result);
        const ok = Store.importAll(payload);
        if (ok) {
          showToast("تم استيراد النسخة الاحتياطية بنجاح ✅");
          setTimeout(() => location.reload(), 900);
        } else {
          showToast("الملف غير صالح، تأكد أنه نسخة احتياطية من Fluent Loop");
        }
      } catch (err) {
        showToast("تعذّرت قراءة الملف — تأكد أنه JSON صحيح");
      }
    };
    reader.readAsText(file);
  },

  fullPlayPause() { st.playerSnap.state === "playing" ? Player.pause() : Player.resume(); },
  fullNext() { Player.next(); },
  fullPrev() { Player.prev(); },
  fullStop() { Player.stop(); st.view = "home"; render(); },
  miniPlayPause() { st.playerSnap.state === "playing" ? Player.pause() : Player.resume(); },
  miniNext() { Player.next(); },
  miniPrev() { Player.prev(); },
  miniStop() { Player.stop(); },
};

// ---------- event delegation ----------
document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) return;
  // <select> elements must only react on "change" — a "click" also fires
  // the instant you tap a <select> to open its native picker, and running
  // setVoice() at that point (before you've picked anything) reads the OLD
  // value, writes it back, and triggers render(), which replaces the very
  // element you're mid-tap on and cancels the picker before it can open.
  // That was the "can't press the dropdown" bug. Checkboxes/number/time/text
  // inputs are unaffected and still need the click path (e.g. checkboxes
  // rely on it), so only <select> and free-text <input> are excluded here.
  if (el.tagName === "SELECT") return;
  if (el.tagName === "INPUT" && !["checkbox", "radio"].includes(el.type)) return;
  const name = el.dataset.action;
  if (actions[name]) actions[name](el.dataset, e);
});
document.addEventListener("change", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) return;
  const name = el.dataset.action;
  if (["setRange", "setCustomDaily", "setNotifTime", "setRate", "setVoice", "importBackupFile"].includes(name) && actions[name]) {
    actions[name](el.dataset, e);
  }
});
document.addEventListener("input", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) return;
  const name = el.dataset.action;
  if (name === "setRate") {
    // Live-update the displayed number only (no full re-render) so dragging
    // the slider stays perfectly smooth; the real commit happens on "change"
    // (i.e. when the finger/mouse is released).
    st.settings.rate = Number(e.target.value);
    document.querySelectorAll(".fl-rate-value").forEach(n => { n.textContent = st.settings.rate.toFixed(2) + "x"; });
    return;
  }
  if (name === "setNote" || name === "setCustomDraft") {
    actions[name](el.dataset, e);
  }
});

// ---------- boot ----------
function initVoices() {
  const check = () => {
    st.voicesReady = getVoices().length > 0;
    render();
  };
  check();
  if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = check;
}

function boot() {
  Store.registerVisit();
  st.visits = Store.loadVisits().count;
  // keep dailyCount in sync with today's key (handles day rollover while app stays open)
  setInterval(() => {
    const fresh = Store.loadDaily().count;
    if (fresh !== st.dailyCount) { st.dailyCount = fresh; render(); }
  }, 60000);

  initVoices();
  if (st.settings.notifEnabled) startReminderLoop(() => st.settings);

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./service-worker.js").catch(() => {});
  }

  render();
}

boot();
