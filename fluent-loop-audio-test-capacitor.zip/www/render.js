import { SITUATIONS, SITUATION_MAP, TOTAL_SENTENCES, PLANS, TARGET_LANGUAGES, targetText } from "./data.js";
import { sentenceKey, Store } from "./storage.js";
import { projectProgress } from "./notifications.js";
import { getEnglishVoices, getArabicVoices, getFrenchVoices, getGermanVoices, getSpanishVoices, voiceGender, isEnhancedVoice, pronunciationSupported } from "./speech.js";

export { PLANS };

function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function icon(name, size = 20) {
  const s = size;
  const icons = {
    play: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`,
    pause: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>`,
    stop: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M6 6h12v12H6z"/></svg>`,
    next: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M6 5l9 7-9 7V5zM17 5h2v14h-2z"/></svg>`,
    prev: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M18 5l-9 7 9 7V5zM5 5h2v14H5z"/></svg>`,
    shuffle: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>`,
    repeatAll: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`,
    repeatOne: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`,
    repeatOff: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="0.45"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`,
    check: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
    flame: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c1 3-2 4-2 7a3 3 0 006 0c1-1 1-3 0-4 2 1 4 4 4 7a8 8 0 11-16 0c0-4 3-6 4-9 .5 1 1 2 2 2 .5-1 .5-2 2-3z"/></svg>`,
    settings: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>`,
    chart: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`,
    home: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>`,
    chevronUp: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>`,
    chevronDown: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`,
    eye: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
    eyeOff: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0112 20c-7 0-11-8-11-8a21.6 21.6 0 015.06-6.06M9.9 4.24A10.94 10.94 0 0112 4c7 0 11 8 11 8a21.6 21.6 0 01-3.22 4.36M14.12 14.12a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`,
    plus: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    minus: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    close: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    list: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>`,
    star: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    starFill: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    medal: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="9" r="6"/><path d="M9 14.5L7 22l5-3 5 3-2-7.5"/></svg>`,
    mic: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`,
  };
  return icons[name] || "";
}

function repeatModeIcon(mode) {
  if (mode === "one") return icon("repeatOne");
  if (mode === "off") return icon("repeatOff");
  return icon("repeatAll");
}

// ---------- Header ----------
export function renderHeader(st) {
  return `
  <div class="fl-header">
    <div class="fl-header-inner">
      <div class="fl-brand" data-action="setView" data-view="home">
        <span class="fl-brand-mark">◐</span>
        <span class="fl-brand-name">Fluent Loop</span>
      </div>
      <div class="fl-header-stats">
        <span class="fl-streak" title="سلسلة الأيام">${icon("flame", 16)} ${st.streak}</span>
        <button class="fl-icon-btn" data-action="setView" data-view="progress" aria-label="تقدمي">${icon("chart", 18)}</button>
        <button class="fl-icon-btn" data-action="setView" data-view="settings" aria-label="الإعدادات">${icon("settings", 18)}</button>
      </div>
    </div>
  </div>`;
}

// ---------- Home ----------
function dailyTarget(st) {
  return st.settings.plan === "custom"
    ? Math.max(1, Number(st.settings.customDaily) || 15)
    : PLANS[st.settings.plan]?.daily || 20;
}

export function renderHome(st) {
  const target = dailyTarget(st);
  const pct = Math.min(100, Math.round((st.dailyCount / target) * 100));

  const cards = SITUATIONS.map(sit => {
    const doneCount = sit.sentences.filter((_, i) => st.progress[sentenceKey(sit.id, i)]?.status === "known").length;
    const complete = doneCount === sit.sentences.length;
    return `
    <button class="fl-sit-card ${complete ? "is-complete" : ""}" data-action="openSituation" data-sit="${sit.id}">
      <div class="fl-sit-card-top">
        <span class="fl-sit-title">${esc(sit.title)}</span>
        ${complete ? `<span class="fl-badge-done">${icon("check", 13)}</span>` : ""}
      </div>
      <div class="fl-sit-sub">${esc(sit.sub)}</div>
      <div class="fl-sit-progress"><div class="fl-sit-progress-fill" style="width:${Math.round((doneCount / sit.sentences.length) * 100)}%"></div></div>
      <div class="fl-sit-count">${doneCount} / ${sit.sentences.length}</div>
    </button>`;
  }).join("");

  return `
  <div class="fl-home">
    <div class="fl-daily-card">
      <div class="fl-daily-ring" style="--pct:${pct}">
        <div class="fl-daily-ring-inner">
          <div class="fl-daily-num">${st.dailyCount}</div>
          <div class="fl-daily-of">من ${target}</div>
        </div>
      </div>
      <div class="fl-daily-info">
        <div class="fl-daily-title">هدفك اليوم</div>
        <div class="fl-daily-sub">${st.dailyCount >= target ? "أنجزت هدف اليوم 🎉 استمر إذا حاب!" : `باقي ${target - st.dailyCount} جملة لهدف اليوم`}</div>
        <div class="fl-daily-chips">
          <span class="fl-chip">${icon("flame", 13)} ${st.streak} يوم متتالي</span>
          <span class="fl-chip">${st.totalTrained} جملة إجمالاً</span>
        </div>
      </div>
    </div>

    ${renderSessionBuilder(st)}

    <div class="fl-quick-links">
      <button class="fl-quick-link" data-action="setView" data-view="custom">${icon("star", 16)} ✍️ جملي الخاصة (${st.custom.length})</button>
      <button class="fl-quick-link" data-action="setView" data-view="progress">${icon("chart", 16)} تقدمي وأوسمتي</button>
    </div>

    <div class="fl-section-title">المواقف</div>
    <div class="fl-sit-grid">${cards}</div>
  </div>`;
}

function selectionTypeTabs(st) {
  const types = [
    { id: "sequential", label: "بعدد" },
    { id: "range", label: "نطاق" },
    { id: "manual", label: "اختيار يدوي" },
  ];
  return `<div class="fl-tabs">${types.map(t => `
    <button class="fl-tab ${st.selectionType === t.id ? "is-active" : ""}" data-action="setSelectionType" data-sel="${t.id}">${t.label}</button>
  `).join("")}</div>`;
}

function sourceListLen(st) {
  return getSourceLen(st, st.sessionSource);
}
function getSourceLen(st, sourceId) {
  if (sourceId === "all") return TOTAL_SENTENCES;
  if (sourceId === "favorites") return st.favorites.size;
  if (sourceId === "weak") return SITUATIONS.reduce((n, sit) => n + sit.sentences.filter((_, i) => st.progress[sentenceKey(sit.id, i)]?.status === "practice").length, 0);
  if (sourceId === "custom") return st.custom.length;
  return SITUATION_MAP[sourceId]?.sentences.length || 0;
}
function getSourceItems(st, sourceId) {
  if (sourceId === "favorites") {
    const out = [];
    SITUATIONS.forEach(sit => sit.sentences.forEach((s, i) => {
      if (st.favorites.has(sit.id + ":" + i)) out.push({ situationId: sit.id, idx: i, sentence: s, title: sit.title });
    }));
    return out;
  }
  if (sourceId === "weak") {
    const out = [];
    SITUATIONS.forEach(sit => sit.sentences.forEach((s, i) => {
      if (st.progress[sentenceKey(sit.id, i)]?.status === "practice") out.push({ situationId: sit.id, idx: i, sentence: s, title: sit.title });
    }));
    return out;
  }
  if (sourceId === "custom") return st.custom.map((c, i) => ({ situationId: "custom", idx: i, sentence: [c.en, c.ar], title: "جملي الخاصة" }));
  if (sourceId === "all") return SITUATIONS.flatMap(sit => sit.sentences.map((s, i) => ({ situationId: sit.id, idx: i, sentence: s, title: sit.title })));
  const sit = SITUATION_MAP[sourceId];
  return sit ? sit.sentences.map((s, i) => ({ situationId: sit.id, idx: i, sentence: s, title: sit.title })) : [];
}
function sourceLabel(st, sourceId) {
  if (sourceId === "all") return `كل المواقف (${TOTAL_SENTENCES} جملة)`;
  if (sourceId === "favorites") return `⭐ المفضلة (${st.favorites.size} جملة)`;
  if (sourceId === "weak") return `🎯 تحتاج مراجعة (${getSourceLen(st, "weak")} جملة)`;
  if (sourceId === "custom") return `✍️ جملي الخاصة (${st.custom.length} جملة)`;
  const sit = SITUATION_MAP[sourceId];
  return sit ? `${sit.title} (${sit.sentences.length} جملة)` : "";
}

// Builds the "بعدد / نطاق / اختيار يدوي" body, scoped to whatever sourceId is
// currently selected (either "all" from the home picker, or a fixed situation
// id when embedded inside a single situation's page).
function renderSelectionBody(st, sourceId) {
  const len = getSourceLen(st, sourceId);
  const counts = [5, 10, 20, 30];

  if (st.selectionType === "range") {
    return `
      <div class="fl-range-row">
        <label>من <input type="number" inputmode="numeric" min="1" max="${len}" value="${st.rangeFrom}" data-action="setRange" data-which="from" class="fl-num-input"></label>
        <label>إلى <input type="number" inputmode="numeric" min="1" max="${len}" value="${st.rangeTo}" data-action="setRange" data-which="to" class="fl-num-input"></label>
        <span class="fl-muted-sm">(${len} جملة متاحة)</span>
      </div>`;
  }
  if (st.selectionType === "manual") {
    const list = getSourceItems(st, sourceId);
    return `
      <div class="fl-manual-actions">
        <button class="fl-mini-btn" data-action="manualSelectAll">تحديد الكل</button>
        <button class="fl-mini-btn" data-action="manualClearAll">إلغاء التحديد</button>
        <span class="fl-muted-sm">${st.manualSelected.size} محددة</span>
      </div>
      <div class="fl-manual-list">
        ${list.length ? list.map(item => {
          const key = item.situationId + ":" + item.idx;
          const checked = st.manualSelected.has(key);
          return `
          <div class="fl-manual-item ${checked ? "is-checked" : ""}" data-action="manualToggle" data-key="${key}">
            <span class="fl-manual-checkbox ${checked ? "is-checked" : ""}">${checked ? icon("check", 12) : ""}</span>
            <span class="fl-manual-en" dir="ltr">${esc(targetText(item.sentence, st.settings.targetLang))}</span>
          </div>`;
        }).join("") : `<div class="fl-empty-small">لا توجد جمل هنا بعد</div>`}
      </div>`;
  }

  // sequential ("بعدد")
  const countRow = `
    <div class="fl-count-row">
      ${counts.map(c => `<button class="fl-mini-btn ${st.sessionCount === c ? "is-active" : ""}" data-action="setSessionCount" data-count="${c}">${c}</button>`).join("")}
      <button class="fl-mini-btn ${st.sessionCount === "all" ? "is-active" : ""}" data-action="setSessionCount" data-count="all">الكل</button>
    </div>`;

  let resumeRow = "";
  if (sourceId !== "all" && sourceId !== "favorites" && sourceId !== "weak") {
    const lastIdx = Store.loadLastIndex(sourceId);
    if (lastIdx >= 0 && lastIdx < len - 1) {
      resumeRow = `
      <div class="fl-resume-row">
        <button class="fl-resume-opt ${!st.resumeMode ? "is-active" : ""}" data-action="setResumeMode" data-mode="start">من البداية</button>
        <button class="fl-resume-opt ${st.resumeMode ? "is-active" : ""}" data-action="setResumeMode" data-mode="resume">أكمل من الجملة ${lastIdx + 2}</button>
      </div>`;
    }
  }

  return countRow + resumeRow;
}

export function renderSessionBuilder(st) {
  const selectionBody = renderSelectionBody(st, st.sessionSource);
  const currentSourceLabel = sourceLabel(st, st.sessionSource);

  return `
  <div class="fl-session-card">
    <div class="fl-section-title">ابدأ جلسة تدريب</div>
    <div class="fl-picker">
      <button type="button" class="fl-picker-btn ${st.sourcePickerOpen ? "is-open" : ""}" data-action="toggleSourcePicker">
        <span>${esc(currentSourceLabel)}</span>
        ${icon("chevronDown", 18)}
      </button>
      ${st.sourcePickerOpen ? `
      <div class="fl-picker-list">
        <button type="button" class="fl-picker-item ${st.sessionSource === "all" ? "is-active" : ""}" data-action="selectSource" data-source="all">كل المواقف (${TOTAL_SENTENCES} جملة)</button>
        <button type="button" class="fl-picker-item ${st.sessionSource === "favorites" ? "is-active" : ""}" data-action="selectSource" data-source="favorites">⭐ المفضلة (${st.favorites.size} جملة)</button>
        <button type="button" class="fl-picker-item ${st.sessionSource === "weak" ? "is-active" : ""}" data-action="selectSource" data-source="weak">🎯 تحتاج مراجعة (${getSourceLen(st, "weak")} جملة)</button>
        <button type="button" class="fl-picker-item ${st.sessionSource === "custom" ? "is-active" : ""}" data-action="selectSource" data-source="custom">✍️ جملي الخاصة (${st.custom.length} جملة)</button>
        ${SITUATIONS.map(sit => `<button type="button" class="fl-picker-item ${st.sessionSource === sit.id ? "is-active" : ""}" data-action="selectSource" data-source="${sit.id}">${esc(sit.title)} (${sit.sentences.length} جملة)</button>`).join("")}
      </div>` : ""}
    </div>
    ${selectionTypeTabs(st)}
    ${selectionBody}
    <label class="fl-inline-toggle">
      <input type="checkbox" data-action="toggleField" data-field="shuffle" ${st.settings.shuffle ? "checked" : ""}>
      <span>${icon("shuffle", 14)} ترتيب عشوائي</span>
    </label>
    <button class="fl-start-btn" data-action="startSession">${icon("play", 18)} ابدأ الجلسة</button>
    ${renderModesRow(st.sessionSource)}
  </div>`;
}

// Secondary activity modes, offered next to "ابدأ الجلسة" everywhere a session
// can be started (home builder + per-situation builder), all scoped to the
// same sourceId that's currently selected.
function renderModesRow(sourceId) {
  return `
    <div class="fl-modes-row">
      <button class="fl-quiz-btn" data-action="startQuiz" data-source="${sourceId}">🧠 اختبار</button>
      <button class="fl-quiz-btn" data-action="startWordOrder" data-source="${sourceId}">🔤 ترتيب الكلمات</button>
      <button class="fl-quiz-btn" data-action="startListenChallenge" data-source="${sourceId}">🎧 استماع فقط</button>
    </div>`;
}

// ---------- Situation ----------
// Compact session-builder embedded inside a single situation's "all sentences" page,
// so choosing 5/10/20/all, a range, or manual sentences doesn't require going back home.
function renderSituationBuilder(st, sit) {
  return `
  <div class="fl-session-card fl-session-card-compact">
    <div class="fl-section-title">تدرّب على هذا الموقف</div>
    ${selectionTypeTabs(st)}
    ${renderSelectionBody(st, sit.id)}
    <label class="fl-inline-toggle">
      <input type="checkbox" data-action="toggleField" data-field="shuffle" ${st.settings.shuffle ? "checked" : ""}>
      <span>${icon("shuffle", 14)} ترتيب عشوائي</span>
    </label>
    <button class="fl-start-btn" data-action="startSituationSession" data-sit="${sit.id}">${icon("play", 18)} ابدأ الجلسة</button>
    ${renderModesRow(sit.id)}
  </div>`;
}

// Pronunciation-check widget: mic button + word-by-word colored feedback.
// Fully feature-detected — on browsers/devices without SpeechRecognition it
// just shows a small explanatory note instead of a broken button.
// Chrome on Android has documented, unresolved reliability problems with
// SpeechRecognition specifically inside *installed* PWA windows (separate
// from the regular getUserMedia mic permission) — the same page working
// fine as a normal browser tab can silently fail to ever hear anything, or
// throw the permission dialog into the "can't ask for permission" state,
// once launched from a home-screen icon. This is a browser limitation, not
// something the app's code can work around — the practical fix is simply
// not using the installed-icon window for this particular feature.
function isStandaloneMode() {
  try {
    return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone === true;
  } catch (e) { return false; }
}

function renderPronCheck(st, targetEn) {
  const pron = st.pron;
  if (!pronunciationSupported()) {
    return `<div class="fl-hint-sm" style="text-align:center;">🎤 فحص النطق غير مدعوم على هذا المتصفح — جرّبه على Chrome بجهاز حقيقي.</div>`;
  }
  return `
    <div class="fl-pron-box">
      ${isStandaloneMode() ? `
        <div class="fl-pron-standalone-warning">
          ⚠️ أنت تفتح التطبيق من الأيقونة المثبتة على الشاشة الرئيسية. متصفح Chrome على أندرويد معروف عنه مشاكل موثّقة بميزة التعرف على الصوت تحديدًا داخل النوافذ المثبتة بهالطريقة (حتى لو الميكروفون نفسه شغّال زين بمواقع ثانية) — هذا قيد بالمتصفح نفسه، مو خلل بالتطبيق. لفحص نطق موثوق: افتح نفس هذا الرابط داخل <b>تبويب Chrome عادي</b> (مو من الأيقونة):
          <div class="fl-pron-url" dir="ltr">${esc(location.href)}</div>
        </div>` : ""}
      <button class="fl-mic-btn ${pron?.listening ? "is-listening" : ""}" data-action="${pron?.listening ? "stopPronCheck" : "startPronCheck"}">
        ${icon("mic", 18)} ${pron?.listening ? (pron.heard ? "✅ سامعينك... تكلم" : "🎧 جاري الاستماع...") : "🎤 جرّب نطقك"}
      </button>
      ${pron?.listening ? `<div class="fl-pron-interim" dir="ltr">${pron.interim ? esc(pron.interim) : "&nbsp;"}</div>` : ""}
      ${pron?.error ? `<div class="fl-pron-error">${esc(pron.error)}</div>` : ""}
      ${pron?.error && !isStandaloneMode() ? `<div class="fl-hint-sm" style="text-align:center;">لو استمرت المشكلة بعد السماح بالميكروفون: افتح الرابط في تبويب متصفح عادي بدل أيقونة التطبيق المثبتة على الشاشة الرئيسية.</div>` : ""}
      ${pron?.result ? `
        <div class="fl-pron-result">
          <div class="fl-pron-score">${pron.result.score}%</div>
          <div class="fl-pron-tokens" dir="ltr">
            ${pron.result.tokens.map(t => `<span class="fl-pron-token ${t.ok ? "is-ok" : "is-bad"}">${esc(t.word)}</span>`).join(" ")}
          </div>
          <button class="fl-link-btn" data-action="resetPronCheck">إعادة المحاولة</button>
        </div>
      ` : ""}
    </div>`;
}

export function renderSituation(st) {
  const sit = SITUATION_MAP[st.activeSitId];
  if (!sit) return `<div class="fl-empty">اختر موقف من الرئيسية</div>`;
  const [en, ar] = sit.sentences[st.idx];
  const targetLang = st.settings.targetLang;
  const enDisplay = targetText(sit.sentences[st.idx], targetLang);
  const key = sentenceKey(sit.id, st.idx);
  const status = st.progress[key]?.status;
  const cur = st.playerSnap.queue[st.playerSnap.pos];
  const isPlayingThis = st.playerSnap.state === "playing" && cur && cur.situationId === sit.id && cur.idx === st.idx && st.playerSnap.queue.length === 1;

  if (st.showAllSentences) {
    return `
    <div class="fl-situation">
      <div class="fl-sit-header">
        <button class="fl-back-btn" data-action="backHome">${icon("prev", 18)} رجوع</button>
        <div class="fl-sit-header-title">${esc(sit.title)}</div>
        <button class="fl-icon-btn" data-action="toggleShowAll" aria-label="اخفاء القائمة">${icon("list", 18)}</button>
      </div>
      ${renderSituationBuilder(st, sit)}
      <div class="fl-section-title">كل الجمل</div>
      <div class="fl-full-list">
        ${sit.sentences.map((s, i) => {
          const k = sentenceKey(sit.id, i);
          const done = st.progress[k]?.status === "known";
          const favKey = sit.id + ":" + i;
          const fav = st.favorites.has(favKey);
          return `
          <div class="fl-full-list-item ${i === st.idx ? "is-current" : ""}" data-action="jumpToIndex" data-idx="${i}">
            <button class="fl-list-play-btn" data-action="playFromList" data-idx="${i}">${icon("play", 14)}</button>
            <div class="fl-list-text">
              <div dir="ltr">${esc(targetText(s, st.settings.targetLang))}</div>
              <div class="fl-list-ar">${esc(s[1])}</div>
            </div>
            <button class="fl-star-btn ${fav ? "is-fav" : ""}" data-action="toggleFavorite" data-key="${favKey}" aria-label="مفضلة">${icon(fav ? "starFill" : "star", 16)}</button>
            ${done ? `<span class="fl-badge-done">${icon("check", 12)}</span>` : ""}
          </div>`;
        }).join("")}
      </div>
    </div>`;
  }

  return `
  <div class="fl-situation">
    <div class="fl-sit-header">
      <button class="fl-back-btn" data-action="backHome">${icon("prev", 18)} رجوع</button>
      <div class="fl-sit-header-title">${esc(sit.title)}</div>
      <button class="fl-icon-btn" data-action="toggleShowAll" aria-label="كل الجمل">${icon("list", 18)}</button>
    </div>

    <div class="fl-card-nav">
      <button class="fl-icon-btn" data-action="prevCardInSituation">${icon("prev", 20)}</button>
      <span class="fl-card-pos">${st.idx + 1} / ${sit.sentences.length}</span>
      <button class="fl-icon-btn" data-action="nextCardInSituation">${icon("next", 20)}</button>
    </div>

    <div class="fl-flashcard" data-action="reveal">
      <button class="fl-star-btn fl-star-card ${st.favorites.has(sit.id + ":" + st.idx) ? "is-fav" : ""}" data-action="toggleFavorite" data-key="${sit.id + ":" + st.idx}" aria-label="مفضلة">${icon(st.favorites.has(sit.id + ":" + st.idx) ? "starFill" : "star", 18)}</button>
      <div class="fl-flashcard-en" dir="ltr">${esc(enDisplay)}</div>
      ${st.revealed ? `<div class="fl-flashcard-ar">${esc(ar)}</div>` : `<div class="fl-flashcard-hint">اضغط لإظهار الترجمة</div>`}
    </div>

    <div class="fl-play-row">
      <button class="fl-play-single-btn ${isPlayingThis ? "is-playing" : ""}" data-action="playSingle">
        ${isPlayingThis ? icon("pause", 18) : icon("play", 18)} ${isPlayingThis ? "إيقاف" : "استمع"}
      </button>
      <button class="fl-play-single-btn" data-action="playSituation" data-sit="${sit.id}">${icon("shuffle", 16)} شغّل كل الموقف</button>
    </div>
    ${isPlayingThis && st.playerSnap.repeatLabel ? `<div class="fl-hint-sm" style="text-align:center;">${esc(st.playerSnap.repeatLabel)}</div>` : ""}

    ${renderPronCheck(st, enDisplay)}

    <div class="fl-mark-row">
      <button class="fl-mark-btn ${status === "practice" ? "is-active" : ""}" data-action="markSentence" data-status="practice">أحتاج تدريب</button>
      <button class="fl-mark-btn is-known ${status === "known" ? "is-active" : ""}" data-action="markSentence" data-status="known">${icon("check", 14)} أتقنتها</button>
    </div>

    <div class="fl-note-box">
      <div class="fl-note-label">ملاحظتك الشخصية</div>
      <textarea class="fl-note-input" placeholder="اكتب طريقتك الخاصة لتذكّر هذه الجملة..." data-action="setNote" data-key="${sit.id}:${st.idx}" rows="2">${esc(st.notes[sit.id + ":" + st.idx] || "")}</textarea>
    </div>

    <button class="fl-link-btn" data-action="customizeThisSituation">تخصيص جلسة على هذا الموقف فقط →</button>
  </div>`;
}

// ---------- Full player ----------
export function renderPlayerFull(st) {
  const snap = st.playerSnap;
  const item = snap.queue[snap.pos];
  if (!item) return `<div class="fl-empty">لا يوجد تشغيل حالياً<br><button class="fl-link-btn" data-action="backHome">رجوع للرئيسية</button></div>`;
  const en = targetText(item.sentence, st.settings.targetLang);
  const ar = item.sentence[1];
  const hidden = st.settings.hideText;

  let enHtml = esc(en);
  if (snap.highlight) {
    const before = esc(en.slice(0, snap.highlight.start));
    const word = esc(en.slice(snap.highlight.start, snap.highlight.end));
    const after = esc(en.slice(snap.highlight.end));
    enHtml = `${before}<span class="fl-hl">${word}</span>${after}`;
  }

  return `
  <div class="fl-player-full">
    <div class="fl-player-top">
      <button class="fl-icon-btn" data-action="fullStop">${icon("stop", 20)}</button>
      <div class="fl-player-pos">${snap.pos + 1} / ${snap.queue.length}</div>
      <span></span>
    </div>
    <div class="fl-player-title">${esc(item.title)}</div>

    <div class="fl-player-card">
      ${hidden
        ? `<div class="fl-listen-only">وضع الاستماع فقط — ركّز على الصوت 🎧</div>`
        : `<div class="fl-player-en" dir="ltr">${enHtml}</div><div class="fl-player-ar">${esc(ar)}</div>`}
      ${snap.repeatLabel ? `<div class="fl-repeat-tag">${snap.repeatLabel}</div>` : ""}
    </div>

    <button class="fl-hide-toggle" data-action="toggleField" data-field="hideText">
      ${hidden ? icon("eye", 15) : icon("eyeOff", 15)} ${hidden ? "إظهار النص" : "إخفاء النص (استماع فقط)"}
    </button>

    <div class="fl-transport">
      <button class="fl-transport-btn ${st.settings.shuffle ? "is-active" : ""}" data-action="toggleField" data-field="shuffle">${icon("shuffle", 20)}</button>
      <button class="fl-transport-btn" data-action="fullPrev">${icon("prev", 26)}</button>
      <button class="fl-transport-play" data-action="fullPlayPause">${snap.state === "playing" ? icon("pause", 26) : icon("play", 26)}</button>
      <button class="fl-transport-btn" data-action="fullNext">${icon("next", 26)}</button>
      <button class="fl-transport-btn fl-repeat-wrap ${snap.repeatMode !== "off" ? "is-active" : ""}" data-action="cycleRepeatMode" title="وضع التكرار">${repeatModeIcon(snap.repeatMode)}${snap.repeatMode === "one" ? `<span class="fl-repeat-badge">1</span>` : ""}</button>
    </div>

    <div class="fl-rate-row">
      <span class="fl-muted-sm">السرعة</span>
      <input type="range" min="0.6" max="1.3" step="0.02" value="${st.settings.rate}" data-action="setRate" class="fl-rate-slider">
      <span class="fl-muted-sm fl-rate-value">${st.settings.rate.toFixed(2)}x</span>
    </div>

    <div class="fl-repeat-steppers">
      ${stepperMini((st.settings.targetLang || "en").toUpperCase(), st.settings.enRepeat, "enRepeat", 1, 6)}
      ${stepperMini("AR", st.settings.arRepeat, "arRepeat", 0, 3)}
    </div>
  </div>`;
}

function stepperMini(label, value, field, min, max) {
  return `
  <div class="fl-repeat-mini">
    <span>${label}</span>
    <button data-action="stepper" data-field="${field}" data-delta="-1" data-min="${min}" data-max="${max}">${icon("minus", 12)}</button>
    <span class="fl-repeat-mini-val">${value}</span>
    <button data-action="stepper" data-field="${field}" data-delta="1" data-min="${min}" data-max="${max}">${icon("plus", 12)}</button>
  </div>`;
}

// ---------- Mini player (persists on every view except full player) ----------
export function renderMiniPlayer(st) {
  const snap = st.playerSnap;
  const item = snap.queue[snap.pos];
  if (!item || st.view === "player" || st.view === "listen") return "";
  return `
  <div class="fl-mini-player" data-action="setView" data-view="player">
    <div class="fl-mini-inner">
      ${icon("chevronUp", 14)}
      <div class="fl-mini-text">
        <div class="fl-mini-en" dir="ltr">${esc(targetText(item.sentence, st.settings.targetLang))}</div>
        <div class="fl-mini-sub">${esc(item.title)} · ${snap.repeatLabel || `${snap.pos + 1}/${snap.queue.length}`}</div>
      </div>
      <button class="fl-icon-btn" data-action="miniPrev">${icon("prev", 18)}</button>
      <button class="fl-mini-play" data-action="miniPlayPause">${snap.state === "playing" ? icon("pause", 16) : icon("play", 16)}</button>
      <button class="fl-icon-btn" data-action="miniNext">${icon("next", 18)}</button>
      <button class="fl-icon-btn" data-action="miniStop">${icon("stop", 16)}</button>
    </div>
  </div>`;
}

// ---------- Settings ----------
function renderVoicePicker(st) {
  const targetLang = ["fr", "de", "es"].includes(st.settings.targetLang) ? st.settings.targetLang : "en";
  const enVoices = getEnglishVoices();
  const arVoices = getArabicVoices();
  const usVoices = enVoices.filter(v => v.lang === "en-US");
  const otherEn = enVoices.filter(v => v.lang !== "en-US");

  const voiceOptionLabel = (v) => {
    const g = voiceGender(v);
    const tag = (g === "male" ? "♂ رجل" : g === "female" ? "♀ امرأة" : "") + (isEnhancedVoice(v) ? " ✨ جودة عالية" : "");
    return `${v.name}${v.lang ? " — " + v.lang : ""}${tag ? " · " + tag : ""}`;
  };

  // Best-match male / female American voices, used by the two quick preset
  // buttons so picking a man's voice doesn't require hunting through the list.
  const bestMale = usVoices.find(v => voiceGender(v) === "male" && isEnhancedVoice(v)) || usVoices.find(v => voiceGender(v) === "male");
  const bestFemale = usVoices.find(v => voiceGender(v) === "female" && isEnhancedVoice(v)) || usVoices.find(v => voiceGender(v) === "female") || usVoices.find(v => !voiceGender(v));

  // Non-English target languages (fr/de/es) all render the same shape of
  // voice picker, just with different voices/locale/labels plugged in.
  const NON_EN_CONFIG = {
    fr: { flag: "🇫🇷", name: "الفرنسية", locale: "fr-FR", localeName: "Français", getVoices: getFrenchVoices, kind: "fr", installName: "فرنسي (Français / fr-FR)" },
    de: { flag: "🇩🇪", name: "الألمانية", locale: "de-DE", localeName: "Deutsch", getVoices: getGermanVoices, kind: "de", installName: "ألماني (Deutsch / de-DE)" },
    es: { flag: "🇪🇸", name: "الإسبانية", locale: "es-ES", localeName: "Español", getVoices: getSpanishVoices, kind: "es", installName: "إسباني (Español / es-ES)" },
  };
  const renderNonEnPicker = (cfg) => {
    const voices = cfg.getVoices();
    const primaryVoices = voices.filter(v => v.lang === cfg.locale);
    const otherVoices = voices.filter(v => v.lang !== cfg.locale);
    const uriField = cfg.kind + "VoiceURI";
    if (!voices.length) {
      return `<div class="fl-hint-sm">⚠️ لا يوجد صوت ${cfg.name} مثبت على جهازك. من إعدادات الهاتف → اللغة والإدخال → تحويل النص إلى كلام، ثبّت صوت ${cfg.installName}.</div>`;
    }
    return `
      <label class="fl-voice-row">
        <span>${cfg.flag} صوت ${cfg.name}</span>
        <select class="fl-select" data-action="setVoice" data-kind="${cfg.kind}">
          <option value="">تلقائي (يفضّل ${cfg.localeName})</option>
          ${primaryVoices.length ? `<optgroup label="${cfg.localeName} (${cfg.locale})">
            ${primaryVoices.map(v => `<option value="${esc(v.voiceURI)}" ${st.settings[uriField] === v.voiceURI ? "selected" : ""}>${esc(voiceOptionLabel(v))}</option>`).join("")}
          </optgroup>` : ""}
          ${otherVoices.length ? `<optgroup label="لهجات أخرى">
            ${otherVoices.map(v => `<option value="${esc(v.voiceURI)}" ${st.settings[uriField] === v.voiceURI ? "selected" : ""}>${esc(voiceOptionLabel(v))}</option>`).join("")}
          </optgroup>` : ""}
        </select>
      </label>`;
  };

  return `
    <div class="fl-voice-picker">
      <label class="fl-voice-row">
        <span>🎯 اللغة اللي تتعلمها</span>
        <div class="fl-lang-grid">
          <button class="fl-quiz-btn ${targetLang === "en" ? "is-active" : ""}" data-action="setTargetLang" data-lang="en">🇺🇸 الإنجليزية</button>
          <button class="fl-quiz-btn ${targetLang === "fr" ? "is-active" : ""}" data-action="setTargetLang" data-lang="fr">🇫🇷 الفرنسية</button>
          <button class="fl-quiz-btn ${targetLang === "de" ? "is-active" : ""}" data-action="setTargetLang" data-lang="de">🇩🇪 الألمانية</button>
          <button class="fl-quiz-btn ${targetLang === "es" ? "is-active" : ""}" data-action="setTargetLang" data-lang="es">🇪🇸 الإسبانية</button>
        </div>
      </label>

      ${targetLang === "en" ? `
      <label class="fl-voice-row">
        <span>🇺🇸 الصوت الإنجليزي داخل التطبيق</span>
        <div class="fl-two-btn-row" style="margin-bottom:8px;">
          <button class="fl-quiz-btn ${st.settings.enVoiceURI === "local:aoede" || !st.settings.enVoiceURI ? "is-active" : ""}" data-action="setVoice" data-kind="en" data-uri="local:aoede">🎙️ Aoede (امرأة)</button>
          <button class="fl-quiz-btn ${st.settings.enVoiceURI === "local:puck" ? "is-active" : ""}" data-action="setVoice" data-kind="en" data-uri="local:puck">🎙️ Puck (رجل)</button>
        </div>
        <div class="fl-hint-sm">هذه الأصوات التجريبية المحلية تعمل من ملفات MP3 داخل التطبيق.</div>
      </label>
      ${enVoices.length ? `
      <label class="fl-voice-row">
        <span>🇺🇸 صوت الإنجليزية (أمريكي)</span>
        ${(bestMale || bestFemale) ? `
        <div class="fl-two-btn-row" style="margin-bottom:8px;">
          <button class="fl-quiz-btn ${st.settings.enVoiceURI === (bestFemale && bestFemale.voiceURI) ? "is-active" : ""}" data-action="setVoice" data-kind="en" data-uri="${bestFemale ? esc(bestFemale.voiceURI) : ""}" ${!bestFemale ? "disabled" : ""}>🎙️♀ صوت امرأة</button>
          <button class="fl-quiz-btn ${st.settings.enVoiceURI === (bestMale && bestMale.voiceURI) ? "is-active" : ""}" data-action="setVoice" data-kind="en" data-uri="${bestMale ? esc(bestMale.voiceURI) : ""}" ${!bestMale ? "disabled" : ""}>🎙️♂ صوت رجل</button>
        </div>` : ""}
        <select class="fl-select" data-action="setVoice" data-kind="en">
          <option value="">تلقائي (يفضّل American English)</option>
          ${usVoices.length ? `<optgroup label="American English (en-US)">
            ${usVoices.map(v => `<option value="${esc(v.voiceURI)}" ${st.settings.enVoiceURI === v.voiceURI ? "selected" : ""}>${esc(voiceOptionLabel(v))}</option>`).join("")}
          </optgroup>` : ""}
          ${otherEn.length ? `<optgroup label="English (لهجات أخرى)">
            ${otherEn.map(v => `<option value="${esc(v.voiceURI)}" ${st.settings.enVoiceURI === v.voiceURI ? "selected" : ""}>${esc(voiceOptionLabel(v))}</option>`).join("")}
          </optgroup>` : ""}
        </select>
      </label>` : `<div class="fl-hint-sm">⚠️ لا يوجد صوت إنجليزي مثبت على جهازك.</div>`) : renderNonEnPicker(NON_EN_CONFIG[targetLang])}

      ${arVoices.length ? `
      <label class="fl-voice-row">
        <span>🇸🇦 صوت العربية</span>
        <select class="fl-select" data-action="setVoice" data-kind="ar">
          <option value="">تلقائي</option>
          ${arVoices.map(v => `<option value="${esc(v.voiceURI)}" ${st.settings.arVoiceURI === v.voiceURI ? "selected" : ""}>${esc(voiceOptionLabel(v))}</option>`).join("")}
        </select>
      </label>` : `<div class="fl-hint-sm">⚠️ لا يوجد صوت عربي مثبت على جهازك. من إعدادات الهاتف → اللغة والإدخال → تحويل النص إلى كلام، ثبّت صوت عربي.</div>`}

      <div class="fl-hint-sm">
        💡 العربية التجريبية تستخدم ملف Shakir المحلي. عند إضافة الحزمة الكاملة لاحقًا ستبقى نفس البنية ويمكن استبدال الملفات فقط.
      </div>
    </div>`;
}

export function renderSettings(st) {
  const s = st.settings;
  return `
  <div class="fl-settings">
    <div class="fl-section-title">خطة التعلم اليومية</div>
    <div class="fl-plan-grid">
      ${Object.entries(PLANS).map(([id, p]) => `
        <button class="fl-plan-card ${s.plan === id ? "is-active" : ""}" data-action="setPlan" data-plan="${id}">
          <div class="fl-plan-label">${p.label}</div>
          <div class="fl-plan-sub">${p.sub}</div>
        </button>`).join("")}
      <button class="fl-plan-card ${s.plan === "custom" ? "is-active" : ""}" data-action="setPlan" data-plan="custom">
        <div class="fl-plan-label">مخصصة</div>
        <div class="fl-plan-sub">${s.customDaily || 15} جملة يومياً</div>
      </button>
    </div>
    ${s.plan === "custom" ? `
    <div class="fl-range-row">
      <label>عدد الجمل يومياً <input type="number" min="1" max="200" value="${s.customDaily || 15}" data-action="setCustomDaily" class="fl-num-input"></label>
    </div>` : ""}

    <div class="fl-section-title">النطق</div>
    <div class="fl-settings-row">
      <span>اللغة تُنطق أولاً</span>
      <div class="fl-seg">
        <button class="fl-seg-btn ${s.startLang === "en" ? "is-active" : ""}" data-action="setStartLang" data-lang="en">${{ en: "English", fr: "Français", de: "Deutsch", es: "Español" }[s.targetLang] || "English"}</button>
        <button class="fl-seg-btn ${s.startLang === "ar" ? "is-active" : ""}" data-action="setStartLang" data-lang="ar">عربي</button>
      </div>
    </div>
    ${settingStepper("عدد تكرار الجملة الإنجليزية", s.enRepeat, "enRepeat", 1, 6)}
    ${settingStepper("عدد تكرار الترجمة العربية", s.arRepeat, "arRepeat", 0, 3)}
    ${settingStepper("الفاصل بين الجمل (ثواني)", s.gapSeconds, "gapSeconds", 0, 6)}
    <div class="fl-range-row">
      <label>سرعة النطق الافتراضية
        <input type="range" min="0.6" max="1.3" step="0.02" value="${s.rate}" data-action="setRate" class="fl-rate-slider">
      </label>
      <span class="fl-muted-sm fl-rate-value">${s.rate.toFixed(2)}x</span>
    </div>
    ${toggleRow("ترتيب عشوائي افتراضياً", s.shuffle, "shuffle")}
    ${toggleRow("إخفاء النص أثناء التشغيل (استماع فقط)", s.hideText, "hideText")}
    ${renderVoicePicker(st)}
    ${!st.voicesReady ? `<div class="fl-warn">⚠️ ما وجدنا أصوات نطق مثبتة بجهازك بعد. لو النطق ما يشتغل: الإعدادات → اللغات → تحويل النص إلى كلام → ثبّت صوت إنجليزي وعربي.</div>` : ""}

    <div class="fl-section-title">التعلم الذكي</div>
    ${toggleRow("أولوية للجمل التي تحتاج مراجعة", s.prioritizeWeak, "prioritizeWeak")}
    <div class="fl-hint-sm">عند التفعيل، الجمل التي وضعت عليها "أحتاج تدريب" تظهر أولاً في جلساتك بدل أن تكون عشوائية.</div>

    <div class="fl-section-title">المظهر</div>
    <div class="fl-settings-row">
      <span>الثيم</span>
      <div class="fl-seg">
        <button class="fl-seg-btn ${s.theme !== "light" ? "is-active" : ""}" data-action="setTheme" data-theme="dark">داكن</button>
        <button class="fl-seg-btn ${s.theme === "light" ? "is-active" : ""}" data-action="setTheme" data-theme="light">فاتح</button>
      </div>
    </div>

    <div class="fl-section-title">التذكيرات</div>
    ${toggleRow("تفعيل إشعارات التذكير اليومية", s.notifEnabled, "notifEnabled")}
    <div class="fl-hint-sm">التوقيت المكتشف تلقائيًا لجهازك: ${esc(Intl.DateTimeFormat().resolvedOptions().timeZone || "غير معروف")} — كل الأوقات أدناه بتوقيتك المحلي فعليًا، لا تحتاج لتحويلها يدويًا.</div>
    ${s.notifEnabled ? `
    <div class="fl-notif-slots">
      ${["morning", "afternoon", "evening"].map(slot => {
        const labels = { morning: "الصباح", afternoon: "العصر", evening: "المساء" };
        const sl = s.notifSlots?.[slot] || { on: false, time: "09:00" };
        return `
        <div class="fl-notif-slot">
          <label class="fl-inline-toggle">
            <input type="checkbox" data-action="toggleNotifSlot" data-slot="${slot}" ${sl.on ? "checked" : ""}>
            <span>${labels[slot]}</span>
          </label>
          <input type="time" value="${sl.time}" data-action="setNotifTime" data-slot="${slot}" class="fl-time-input">
        </div>`;
      }).join("")}
    </div>` : ""}

    <div class="fl-section-title">النسخ الاحتياطي والنقل بين الأجهزة</div>
    <div class="fl-hint-sm">كل بياناتك محفوظة على هذا الجهاز فقط. صدّر نسخة احتياطية (ملف واحد) قبل تغيير الهاتف أو مسح المتصفح، واستوردها لاحقًا لاسترجاع تقدمك بالكامل.</div>
    <div class="fl-two-btn-row" style="margin-bottom:16px;">
      <button class="fl-quiz-btn" data-action="exportBackup">⬇️ تصدير نسخة احتياطية</button>
      <label class="fl-quiz-btn fl-import-label">
        ⬆️ استيراد نسخة
        <input type="file" accept="application/json" data-action="importBackupFile" style="display:none;">
      </label>
    </div>

    <div class="fl-section-title">البيانات</div>
    <button class="fl-danger-btn" data-action="confirmReset">إعادة تصفير كل التقدم والإحصائيات</button>
  </div>`;
}

function settingStepper(label, value, field, min, max) {
  return `
  <div class="fl-settings-row">
    <span>${label}</span>
    <div class="fl-stepper">
      <button data-action="stepper" data-field="${field}" data-delta="-1" data-min="${min}" data-max="${max}">${icon("minus", 14)}</button>
      <span class="fl-stepper-val">${value}</span>
      <button data-action="stepper" data-field="${field}" data-delta="1" data-min="${min}" data-max="${max}">${icon("plus", 14)}</button>
    </div>
  </div>`;
}
function toggleRow(label, value, field) {
  return `
  <div class="fl-settings-row">
    <span>${label}</span>
    <button class="fl-switch ${value ? "is-on" : ""}" data-action="toggleField" data-field="${field}">
      <span class="fl-switch-knob"></span>
    </button>
  </div>`;
}

// ---------- Achievements ----------
const BADGES = [
  { id: "s3", label: "3 أيام متتالية", need: (st) => st.streak >= 3, icon: "flame" },
  { id: "s7", label: "أسبوع كامل 🔥", need: (st) => st.streak >= 7, icon: "flame" },
  { id: "s30", label: "شهر كامل! 🏆", need: (st) => st.streak >= 30, icon: "flame" },
  { id: "t50", label: "50 جملة تدربت", need: (st) => st.totalTrained >= 50, icon: "medal" },
  { id: "t100", label: "100 جملة", need: (st) => st.totalTrained >= 100, icon: "medal" },
  { id: "t250", label: "250 جملة", need: (st) => st.totalTrained >= 250, icon: "medal" },
  { id: "t500", label: "500 جملة", need: (st) => st.totalTrained >= 500, icon: "medal" },
  { id: "master1", label: "إتقان موقف كامل", need: (st) => SITUATIONS.some(sit => sit.sentences.every((_, i) => st.progress[sentenceKey(sit.id, i)]?.status === "known")), icon: "medal" },
  { id: "masterAll", label: "إتقان كل المواقف!", need: (st) => SITUATIONS.every(sit => sit.sentences.every((_, i) => st.progress[sentenceKey(sit.id, i)]?.status === "known")), icon: "medal" },
  { id: "fav5", label: "5 جمل مفضلة", need: (st) => st.favorites.size >= 5, icon: "starFill" },
];

// ---------- Progress ----------
export function renderProgress(st) {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    days.push({ key, label: d.toLocaleDateString("ar", { weekday: "short" }), count: st.history[key] || 0 });
  }
  const maxCount = Math.max(1, ...days.map(d => d.count));
  const avgDaily = days.reduce((a, d) => a + d.count, 0) / 7;
  const projections = projectProgress(avgDaily || 1, st.totalTrained);

  const doneTotal = Object.values(st.progress).filter(p => p.status === "known").length;
  const weakCount = getSourceLen(st, "weak");
  const earned = BADGES.filter(b => b.need(st));

  return `
  <div class="fl-progress">
    <div class="fl-stat-grid">
      <div class="fl-stat-card"><div class="fl-stat-num">${st.streak}</div><div class="fl-stat-label">سلسلة أيام 🔥</div></div>
      <div class="fl-stat-card"><div class="fl-stat-num">${st.visits}</div><div class="fl-stat-label">مرات الدخول</div></div>
      <div class="fl-stat-card"><div class="fl-stat-num">${st.totalTrained}</div><div class="fl-stat-label">جملة تدربت عليها</div></div>
      <div class="fl-stat-card"><div class="fl-stat-num">${doneTotal}/${TOTAL_SENTENCES}</div><div class="fl-stat-label">جملة أتقنتها</div></div>
    </div>

    <div class="fl-quick-row">
      <button class="fl-quick-card" data-action="startQuickSession" data-source="weak">
        <div class="fl-quick-num">${weakCount}</div>
        <div class="fl-quick-label">🎯 تحتاج مراجعة — اضغط للتدرب</div>
      </button>
      <button class="fl-quick-card" data-action="startQuickSession" data-source="favorites">
        <div class="fl-quick-num">${st.favorites.size}</div>
        <div class="fl-quick-label">⭐ المفضلة — اضغط للتدرب</div>
      </button>
    </div>

    <div class="fl-section-title">أوسمتك (${earned.length}/${BADGES.length})</div>
    <div class="fl-badge-grid">
      ${BADGES.map(b => {
        const on = earned.some(e => e.id === b.id);
        return `<div class="fl-badge-chip ${on ? "is-earned" : ""}">${icon(b.icon, 18)}<span>${b.label}</span></div>`;
      }).join("")}
    </div>

    <div class="fl-section-title">آخر ٧ أيام</div>
    <div class="fl-bar-chart">
      ${days.map(d => `
        <div class="fl-bar-col">
          <div class="fl-bar-track"><div class="fl-bar-fill" style="height:${Math.round((d.count / maxCount) * 100)}%"></div></div>
          <div class="fl-bar-val">${d.count}</div>
          <div class="fl-bar-label">${d.label}</div>
        </div>`).join("")}
    </div>

    <div class="fl-section-title">لو استمريت بمعدلك الحالي (${avgDaily.toFixed(1)} جملة/يوم)</div>
    <div class="fl-projection-list">
      ${projections.map(p => `
        <div class="fl-projection-row">
          <span>${p.label}</span>
          <span class="fl-projection-num">${p.total} جملة</span>
        </div>`).join("")}
    </div>

    <div class="fl-section-title">تقدمك بكل موقف</div>
    <div class="fl-sit-progress-list">
      ${SITUATIONS.map(sit => {
        const done = sit.sentences.filter((_, i) => st.progress[sentenceKey(sit.id, i)]?.status === "known").length;
        return `
        <div class="fl-sit-progress-row">
          <span>${esc(sit.title)}</span>
          <div class="fl-sit-progress-bar"><div style="width:${Math.round((done / sit.sentences.length) * 100)}%"></div></div>
          <span class="fl-muted-sm">${done}/${sit.sentences.length}</span>
        </div>`;
      }).join("")}
    </div>
  </div>`;
}

// ---------- Custom sentences manager ----------
export function renderCustomManager(st) {
  return `
  <div class="fl-custom-manager">
    <div class="fl-sit-header">
      <button class="fl-back-btn" data-action="backHome">${icon("prev", 18)} رجوع</button>
      <div class="fl-sit-header-title">✍️ جملي الخاصة</div>
      <span style="width:40px"></span>
    </div>

    <div class="fl-add-custom-card">
      <div class="fl-section-title">أضف جملة جديدة</div>
      <input type="text" class="fl-select" dir="ltr" placeholder="English sentence" data-action="setCustomDraft" data-field="en" value="${esc(st.customDraftEn)}">
      <input type="text" class="fl-select" placeholder="ترجمتها بالعربي" data-action="setCustomDraft" data-field="ar" value="${esc(st.customDraftAr)}">
      <button class="fl-start-btn" data-action="addCustomSentence">${icon("plus", 18)} إضافة</button>
    </div>

    <div class="fl-section-title">جملك (${st.custom.length})</div>
    ${st.custom.length ? `
    <div class="fl-full-list">
      ${st.custom.map((c, i) => `
        <div class="fl-full-list-item">
          <button class="fl-list-play-btn" data-action="playCustom" data-idx="${i}">${icon("play", 14)}</button>
          <div class="fl-list-text">
            <div dir="ltr">${esc(c.en)}</div>
            <div class="fl-list-ar">${esc(c.ar)}</div>
          </div>
          <button class="fl-star-btn" data-action="deleteCustomSentence" data-idx="${i}" aria-label="حذف">${icon("close", 16)}</button>
        </div>`).join("")}
    </div>
    <button class="fl-start-btn" data-action="startQuickSession" data-source="custom" style="margin-top:14px;">${icon("play", 18)} ابدأ جلسة على جملي</button>
    ` : `<div class="fl-empty-small">لم تضف أي جملة بعد — أضف أول جملة لك أعلاه ✍️</div>`}
  </div>`;
}

// ---------- Quiz mode (multiple-choice) ----------
export function renderQuiz(st) {
  const quiz = st.quiz;
  if (!quiz) return `<div class="fl-empty">لا يوجد اختبار حالياً<br><button class="fl-link-btn" data-action="backHome">رجوع للرئيسية</button></div>`;

  if (quiz.done) {
    const pct = Math.round((quiz.score / quiz.questions.length) * 100);
    const msg = pct >= 90 ? "ممتاز جداً! 🏆" : pct >= 70 ? "أحسنت! 👏" : pct >= 50 ? "لا بأس، واصل التدريب 💪" : "تحتاج مراجعة أكثر، لا تستسلم 🔁";
    return `
    <div class="fl-quiz-done">
      <div class="fl-quiz-score-ring" style="--pct:${pct}">
        <div class="fl-quiz-score-num">${quiz.score}/${quiz.questions.length}</div>
      </div>
      <div class="fl-quiz-msg">${msg}</div>
      <button class="fl-start-btn" data-action="startQuiz" data-source="${st.sessionSource}">${icon("shuffle", 18)} اختبار جديد</button>
      <button class="fl-link-btn" data-action="quizExit">رجوع للرئيسية</button>
    </div>`;
  }

  const q = quiz.questions[quiz.pos];
  const picked = quiz.picked;
  return `
  <div class="fl-quiz">
    <div class="fl-sit-header">
      <button class="fl-back-btn" data-action="quizExit">${icon("prev", 18)} خروج</button>
      <div class="fl-sit-header-title">سؤال ${quiz.pos + 1} / ${quiz.questions.length}</div>
      <span class="fl-muted-sm">${quiz.score} ✓</span>
    </div>

    <div class="fl-quiz-question">
      <div class="fl-muted-sm">اختر الترجمة الصحيحة</div>
      <div class="fl-flashcard-en" dir="ltr">${esc(targetText(q.item.sentence, st.settings.targetLang))}</div>
    </div>

    <div class="fl-quiz-options">
      ${q.options.map((opt, i) => {
        let cls = "";
        if (picked != null) {
          if (opt === q.correct) cls = "is-correct";
          else if (i === picked) cls = "is-wrong";
        }
        return `<button class="fl-quiz-opt ${cls}" data-action="quizPick" data-choice="${i}" ${picked != null ? "disabled" : ""}>${esc(opt)}</button>`;
      }).join("")}
    </div>

    ${picked != null ? `<button class="fl-start-btn" data-action="quizNext">${quiz.pos + 1 >= quiz.questions.length ? "عرض النتيجة" : "السؤال التالي"} ${icon("next", 18)}</button>` : ""}
  </div>`;
}

// ---------- Word-order exercise ----------
export function renderWordOrder(st) {
  const wo = st.wordOrder;
  if (!wo) return `<div class="fl-empty">لا يوجد تمرين حالياً<br><button class="fl-link-btn" data-action="backHome">رجوع للرئيسية</button></div>`;

  if (wo.done) {
    const pct = Math.round((wo.score / wo.items.length) * 100);
    return `
    <div class="fl-quiz-done">
      <div class="fl-quiz-score-ring" style="--pct:${pct}"><div class="fl-quiz-score-num">${wo.score}/${wo.items.length}</div></div>
      <div class="fl-quiz-msg">${pct >= 80 ? "ترتيب ممتاز! 🏆" : pct >= 50 ? "جيد، واصل التدريب 💪" : "تحتاج تدريب أكثر على الترتيب 🔁"}</div>
      <button class="fl-start-btn" data-action="startWordOrder" data-source="${st.sessionSource}">${icon("shuffle", 18)} تمرين جديد</button>
      <button class="fl-link-btn" data-action="woExit">رجوع للرئيسية</button>
    </div>`;
  }

  const cur = wo.items[wo.pos];
  return `
  <div class="fl-quiz">
    <div class="fl-sit-header">
      <button class="fl-back-btn" data-action="woExit">${icon("prev", 18)} خروج</button>
      <div class="fl-sit-header-title">رتّب الجملة ${wo.pos + 1} / ${wo.items.length}</div>
      <span class="fl-muted-sm">${wo.score} ✓</span>
    </div>

    <div class="fl-quiz-question">
      <div class="fl-muted-sm">رتّب الكلمات لتكوين الجملة الصحيحة</div>
      <div class="fl-flashcard-ar" style="margin-top:8px;">${esc(cur.item.sentence[1])}</div>
    </div>

    <div class="fl-wo-built" dir="ltr">
      ${wo.built.length ? wo.built.map(w => `<span class="fl-wo-chip is-built">${esc(w.w)}</span>`).join("") : `<span class="fl-muted-sm">اضغط الكلمات بالأسفل بالترتيب الصحيح</span>`}
    </div>

    <div class="fl-wo-bank" dir="ltr">
      ${wo.remaining.map((w, i) => `<button class="fl-wo-chip" data-action="woPick" data-i="${i}" ${wo.checked ? "disabled" : ""}>${esc(w.w)}</button>`).join("")}
    </div>

    ${wo.checked ? `
      <div class="fl-wo-feedback ${wo.correct ? "is-correct" : "is-wrong"}">
        ${wo.correct ? "✅ صحيح!" : `❌ الصحيح: <span dir="ltr">${esc(targetText(cur.item.sentence, st.settings.targetLang))}</span>`}
      </div>
      <button class="fl-start-btn" data-action="woNext">${wo.pos + 1 >= wo.items.length ? "عرض النتيجة" : "الجملة التالية"} ${icon("next", 18)}</button>
    ` : `
      <div class="fl-two-btn-row">
        <button class="fl-start-btn" data-action="woCheck" ${!wo.built.length ? "disabled" : ""}>تحقق ${icon("check", 16)}</button>
        <button class="fl-quiz-btn" data-action="woUndo" ${!wo.built.length ? "disabled" : ""}>تراجع عن آخر كلمة</button>
      </div>
    `}
  </div>`;
}

// ---------- Listening-only challenge ----------
export function renderListenChallenge(st) {
  const lst = st.listen;
  if (!lst) return `<div class="fl-empty">لا يوجد تحدي حالياً<br><button class="fl-link-btn" data-action="backHome">رجوع للرئيسية</button></div>`;

  if (lst.done) {
    const pct = Math.round((lst.score / lst.items.length) * 100);
    return `
    <div class="fl-quiz-done">
      <div class="fl-quiz-score-ring" style="--pct:${pct}"><div class="fl-quiz-score-num">${lst.score}/${lst.items.length}</div></div>
      <div class="fl-quiz-msg">أحسنت! راجعت ${lst.items.length} جملة سمعياً 🎧</div>
      <button class="fl-start-btn" data-action="startListenChallenge" data-source="${st.sessionSource}">${icon("shuffle", 18)} تحدٍ جديد</button>
      <button class="fl-link-btn" data-action="listenExit">رجوع للرئيسية</button>
    </div>`;
  }

  const cur = lst.items[lst.pos];
  return `
  <div class="fl-quiz">
    <div class="fl-sit-header">
      <button class="fl-back-btn" data-action="listenExit">${icon("prev", 18)} خروج</button>
      <div class="fl-sit-header-title">استماع ${lst.pos + 1} / ${lst.items.length}</div>
      <span class="fl-muted-sm">${lst.score} ✓</span>
    </div>

    <div class="fl-flashcard" data-action="listenReplay">
      ${lst.revealed ? `
        <div class="fl-flashcard-en" dir="ltr">${esc(targetText(cur.sentence, st.settings.targetLang))}</div>
        <div class="fl-flashcard-ar">${esc(cur.sentence[1])}</div>
      ` : `
        <div class="fl-listen-icon">${icon("play", 40)}</div>
        <div class="fl-flashcard-hint">اسمع الجملة، ثم قيّم نفسك — اضغط للإعادة</div>
      `}
    </div>

    ${!lst.revealed ? `<button class="fl-quiz-btn" data-action="listenReveal" style="width:100%;margin-top:10px;">${icon("eye", 15)} إظهار النص</button>` : ""}

    ${!lst.answered ? `
      <div class="fl-two-btn-row" style="margin-top:16px;">
        <button class="fl-mark-btn is-known" data-action="listenSelfMark" data-knew="1">${icon("check", 14)} فهمتها</button>
        <button class="fl-mark-btn" data-action="listenSelfMark" data-knew="0">أحتاج مراجعة</button>
      </div>
    ` : `<button class="fl-start-btn" data-action="listenNext" style="margin-top:16px;">${lst.pos + 1 >= lst.items.length ? "عرض النتيجة" : "التالي"} ${icon("next", 18)}</button>`}
  </div>`;
}
