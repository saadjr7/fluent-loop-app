// Bump this on every deploy so returning visitors get the new files instead
// of being stuck on a stale cached version forever.
const CACHE_VERSION = "fluent-loop-v3-audio-test";
const ASSETS = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./data.js",
  "./storage.js",
  "./speech.js",
  "./notifications.js",
  "./render.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./audio/aoede/001.mp3","./audio/aoede/002.mp3","./audio/aoede/003.mp3","./audio/aoede/004.mp3","./audio/aoede/005.mp3","./audio/aoede/006.mp3","./audio/aoede/007.mp3","./audio/aoede/008.mp3","./audio/aoede/009.mp3","./audio/aoede/010.mp3",
  "./audio/puck/001.mp3","./audio/puck/002.mp3","./audio/puck/003.mp3","./audio/puck/004.mp3","./audio/puck/005.mp3","./audio/puck/006.mp3","./audio/puck/007.mp3","./audio/puck/008.mp3","./audio/puck/009.mp3","./audio/puck/010.mp3",
  "./audio/arabic/001.mp3","./audio/arabic/002.mp3","./audio/arabic/003.mp3","./audio/arabic/004.mp3","./audio/arabic/005.mp3","./audio/arabic/006.mp3","./audio/arabic/007.mp3","./audio/arabic/008.mp3","./audio/arabic/009.mp3","./audio/arabic/010.mp3",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Network-first for our own JS/HTML/CSS so updates show up promptly; falls
// back to cache when offline. Cache-first for icons (rarely change).
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  if (url.pathname.includes("/icons/")) {
    event.respondWith(
      caches.match(event.request).then((cached) => cached || fetch(event.request))
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, copy));
        return res;
      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match("./index.html")))
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clients) => {
      for (const c of clients) { if ("focus" in c) return c.focus(); }
      if (self.clients.openWindow) return self.clients.openWindow("./");
    })
  );
});
