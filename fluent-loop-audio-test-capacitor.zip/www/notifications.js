// ---------- Reminders ----------
// Best-effort, in-page reminders. Honest limitation: this can only fire
// while the browser process is alive (tab open, or — on Android/desktop
// Chrome — recently backgrounded). iOS Safari fully suspends page JS in the
// background, so no website-only notification can survive that; the only
// real fix there is a native push server, which is out of scope for a
// static site. We check once a minute and fire anything due "today".

import { MOTIVATIONAL_MESSAGES } from "./data.js";

let loopHandle = null;
let firedToday = new Set(); // "slotKey:YYYY-MM-DD" already fired

export async function requestNotifPermission() {
  if (!("Notification" in window)) return "unsupported";
  if (Notification.permission === "granted") return "granted";
  if (Notification.permission === "denied") return "denied";
  try {
    return await Notification.requestPermission();
  } catch (e) {
    return "denied";
  }
}

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function randomMessage() {
  return MOTIVATIONAL_MESSAGES[Math.floor(Math.random() * MOTIVATIONAL_MESSAGES.length)];
}

function fireNotification(title, body) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  try {
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.ready.then(reg => {
        reg.showNotification(title, { body, icon: "./icons/icon-192.png", badge: "./icons/icon-192.png" });
      });
    } else {
      new Notification(title, { body, icon: "./icons/icon-192.png" });
    }
  } catch (e) {}
}

export function startReminderLoop(getSettings) {
  stopReminderLoop();
  const check = () => {
    const settings = getSettings ? getSettings() : null;
    if (!settings || !settings.notifEnabled || !settings.notifSlots) return;
    const now = new Date();
    const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const day = todayStr();
    Object.entries(settings.notifSlots).forEach(([slotName, slot]) => {
      if (!slot || !slot.on) return;
      if (slot.time !== hhmm) return;
      const fireKey = `${slotName}:${day}`;
      if (firedToday.has(fireKey)) return;
      firedToday.add(fireKey);
      fireNotification("Fluent Loop 🎧", randomMessage());
    });
  };
  check();
  loopHandle = setInterval(check, 30 * 1000);
}

export function stopReminderLoop() {
  if (loopHandle) { clearInterval(loopHandle); loopHandle = null; }
}

// ---------- Progress projections ----------
// Given a daily-sentence rate, project totals forward. Used on the Progress
// page to show "at this pace, in a month you'll have learned X sentences".
export function projectProgress(dailyRate, totalSoFar) {
  const horizons = [
    { label: "أسبوع", days: 7 },
    { label: "شهر", days: 30 },
    { label: "شهرين", days: 60 },
    { label: "٣ أشهر", days: 90 },
    { label: "٦ أشهر", days: 180 },
    { label: "سنة", days: 365 },
  ];
  return horizons.map(h => ({
    label: h.label,
    total: Math.round(totalSoFar + dailyRate * h.days),
  }));
}
