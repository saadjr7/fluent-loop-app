// ---------- Persistence (real localStorage, never window.storage) ----------
// window.storage does not exist in real browsers — it was the root cause of
// the black-screen crash in earlier builds. Every read/write here is wrapped
// in try/catch so a quota error or private-browsing restriction can never
// take down the whole app.

const KEYS = {
  settings: "fl:settings",
  daily: "fl:daily",       // { date, count }
  streak: "fl:streak",     // { count, last }
  visits: "fl:visits",     // { count, days: { "YYYY-MM-DD": true } }
  total: "fl:totalTrained",
  progress: "fl:progress", // { "prog:sitId:idx": {status, ts} }
  history: "fl:history",   // { "YYYY-MM-DD": count }
  lastIndex: "fl:lastIndex", // { sourceId: idx }  — bookmark for "resume where I left off"
  favorites: "fl:favorites", // array of "sitId:idx" keys
  notes: "fl:notes",         // { "sitId:idx": "note text" }
  custom: "fl:custom",       // [{ id, en, ar }]
};

function safeGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw == null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}
function safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    return false;
  }
}

export function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
export function sentenceKey(situationId, idx) {
  return `prog:${situationId}:${idx}`;
}
export function daysAgoKey(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export const Store = {
  loadSettings() {
    return safeGet(KEYS.settings, null);
  },
  saveSettings(s) {
    return safeSet(KEYS.settings, s);
  },

  loadDaily() {
    const d = safeGet(KEYS.daily, { date: todayKey(), count: 0 });
    if (d.date !== todayKey()) return { date: todayKey(), count: 0 };
    return d;
  },
  saveDaily(count) {
    return safeSet(KEYS.daily, { date: todayKey(), count });
  },

  loadStreak() {
    return safeGet(KEYS.streak, { count: 0, last: null });
  },
  saveStreak(s) {
    return safeSet(KEYS.streak, s);
  },

  loadVisits() {
    return safeGet(KEYS.visits, { count: 0, days: {} });
  },
  registerVisit() {
    const v = this.loadVisits();
    const key = todayKey();
    if (!v.days[key]) {
      v.days[key] = true;
      v.count += 1;
      safeSet(KEYS.visits, v);
    }
    return v;
  },

  loadTotalTrained() {
    return safeGet(KEYS.total, 0);
  },
  saveTotalTrained(n) {
    return safeSet(KEYS.total, n);
  },

  loadProgress() {
    return safeGet(KEYS.progress, {});
  },
  saveProgress(p) {
    return safeSet(KEYS.progress, p);
  },

  loadHistory() {
    return safeGet(KEYS.history, {});
  },
  saveHistory(h) {
    return safeSet(KEYS.history, h);
  },

  // ---- bookmark: last sentence index reached per source (situation id or "all") ----
  loadLastIndexMap() {
    return safeGet(KEYS.lastIndex, {});
  },
  loadLastIndex(sourceId) {
    const m = this.loadLastIndexMap();
    return typeof m[sourceId] === "number" ? m[sourceId] : -1;
  },
  saveLastIndex(sourceId, idx) {
    if (!sourceId) return;
    const m = this.loadLastIndexMap();
    m[sourceId] = idx;
    safeSet(KEYS.lastIndex, m);
  },

  // ---- favorites (starred sentences), stored as an array of "sitId:idx" keys ----
  loadFavorites() {
    return safeGet(KEYS.favorites, []);
  },
  saveFavorites(arr) {
    return safeSet(KEYS.favorites, arr);
  },

  // ---- personal notes per sentence ----
  loadNotes() {
    return safeGet(KEYS.notes, {});
  },
  saveNotes(obj) {
    return safeSet(KEYS.notes, obj);
  },

  // ---- user's own custom sentences ----
  loadCustom() {
    return safeGet(KEYS.custom, []);
  },
  saveCustom(arr) {
    return safeSet(KEYS.custom, arr);
  },

  // wipe everything (used by the settings "reset" action)
  resetAll() {
    Object.values(KEYS).forEach(k => {
      try { localStorage.removeItem(k); } catch (e) {}
    });
  },

  // ---- backup: export/import everything as a single JSON blob (a practical
  // stand-in for cloud sync — no backend needed, works fully offline) ----
  exportAll() {
    const out = {};
    Object.entries(KEYS).forEach(([name, key]) => {
      const raw = localStorage.getItem(key);
      if (raw != null) out[name] = JSON.parse(raw);
    });
    return { app: "fluent-loop", version: 1, exportedAt: new Date().toISOString(), data: out };
  },
  importAll(payload) {
    if (!payload || payload.app !== "fluent-loop" || !payload.data) return false;
    try {
      Object.entries(payload.data).forEach(([name, value]) => {
        if (KEYS[name]) localStorage.setItem(KEYS[name], JSON.stringify(value));
      });
      return true;
    } catch (e) {
      return false;
    }
  },
};
