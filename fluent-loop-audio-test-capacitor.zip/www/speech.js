import { targetText } from "./data.js";

// ---------- Speech engine ----------
// Every playback bug reported before traced back to one thing: overlapping
// async play-loops racing each other (pressing play/pause/next fast, or
// changing the rate mid-sentence, could spawn a second loop while the first
// was still alive). Everything here is gated by a single incrementing
// `token`: a loop iteration checks its captured token against the live one
// before every side effect, and silently stops if it's gone stale. There is
// exactly one play-loop alive at any time, ever.

export function getVoices() {
  return window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
}

// Voices actually useful for this app: American-English voices (we default
// to en-US specifically, not just any English accent) and any Arabic voice.
export function getEnglishVoices() {
  return getVoices().filter(v => v.lang?.toLowerCase().startsWith("en"));
}
export function getArabicVoices() {
  return getVoices().filter(v => v.lang?.toLowerCase().startsWith("ar"));
}
export function getFrenchVoices() {
  return getVoices().filter(v => v.lang?.toLowerCase().startsWith("fr"));
}
export function getGermanVoices() {
  return getVoices().filter(v => v.lang?.toLowerCase().startsWith("de"));
}
export function getSpanishVoices() {
  return getVoices().filter(v => v.lang?.toLowerCase().startsWith("es"));
}

// Best-effort gender tagging from the voice's name. Browsers/OSes don't expose
// a real gender field, so we match against the common named voices every
// major platform ships (Android/Chrome, iOS/Safari, Windows, macOS).
const MALE_NAME_HINTS = /\b(david|guy|fred|alex|aaron|eric|roger|christopher|tom|mark|daniel|george|james|kevin|ryan|matthew|male)\b/i;
const FEMALE_NAME_HINTS = /\b(samantha|zira|jenny|aria|susan|karen|victoria|allison|ava|emma|kate|linda|moira|nicky|sara|serena|female)\b/i;
export function voiceGender(v) {
  if (!v) return null;
  if (MALE_NAME_HINTS.test(v.name)) return "male";
  if (FEMALE_NAME_HINTS.test(v.name)) return "female";
  return null;
}
// Voices whose name hints at a higher-quality neural/enhanced engine (iOS
// "Enhanced/Premium" voices, Android/Chrome "Google" WaveNet voices, Edge
// "Natural" voices) — these sound noticeably more human than the robotic
// compact/default system voice, and are completely free once enabled on-device.
export function isEnhancedVoice(v) {
  return /google|natural|neural|enhanced|premium|wavenet/i.test(v.name || "");
}

// Per-language config used to generalize voice-picking to whichever
// language the person is currently learning, without hand-writing a new
// if/else branch every time a language gets added.
const LANG_CONFIG = {
  en: { prefsKey: "enVoiceURI", primaryLocale: "en-US", prefix: "en" },
  fr: { prefsKey: "frVoiceURI", primaryLocale: "fr-FR", prefix: "fr" },
  de: { prefsKey: "deVoiceURI", primaryLocale: "de-DE", prefix: "de" },
  es: { prefsKey: "esVoiceURI", primaryLocale: "es-ES", prefix: "es" },
};

// Picks the best available voice for a given target language: an explicit
// user choice first, then the highest-quality voice matching the primary
// locale (e.g. en-US, fr-FR), then any voice at all in that language family.
function pickTargetVoice(prefs, targetLang) {
  const cfg = LANG_CONFIG[targetLang] || LANG_CONFIG.en;
  const voices = getVoices();
  let voice = null;
  if (prefs && prefs[cfg.prefsKey]) voice = voices.find(v => v.voiceURI === prefs[cfg.prefsKey]) || null;
  if (!voice) {
    const primary = voices.filter(v => v.lang === cfg.primaryLocale);
    voice = primary.find(isEnhancedVoice) || primary[0] ||
      voices.find(v => v.lang?.toLowerCase().startsWith(cfg.prefix)) || null;
  }
  return voice;
}

function pickVoices(prefs) {
  const voices = getVoices();
  let enVoice = null;
  if (prefs && prefs.enVoiceURI) enVoice = voices.find(v => v.voiceURI === prefs.enVoiceURI) || null;
  if (!enVoice) {
    const usVoices = voices.filter(v => v.lang === "en-US");
    enVoice =
      // Prefer a genuine American-English voice, and among those the
      // higher-quality "natural/neural" sounding ones when the OS exposes them.
      usVoices.find(isEnhancedVoice) ||
      usVoices.find(v => v.lang === "en-US") ||
      voices.find(v => v.lang?.startsWith("en")) || null;
  }
  let enVoiceMale = null;
  if (prefs && prefs.enVoiceMaleURI) enVoiceMale = voices.find(v => v.voiceURI === prefs.enVoiceMaleURI) || null;
  if (!enVoiceMale) {
    const usVoices = voices.filter(v => v.lang === "en-US");
    enVoiceMale = usVoices.find(v => voiceGender(v) === "male" && isEnhancedVoice(v)) ||
      usVoices.find(v => voiceGender(v) === "male") || null;
  }
  let arVoice = null;
  if (prefs && prefs.arVoiceURI) arVoice = voices.find(v => v.voiceURI === prefs.arVoiceURI) || null;
  if (!arVoice) {
    // Always prefer an explicit Arabic voice for Arabic text — never silently
    // fall back to the English voice for Arabic (that was the "Arabic mispronounced" bug).
    const arVoices = voices.filter(v => v.lang?.startsWith("ar"));
    arVoice =
      arVoices.find(v => v.lang === "ar-SA" && isEnhancedVoice(v)) ||
      arVoices.find(v => v.lang === "ar-SA") ||
      arVoices[0] || null;
  }
  const targetLang = prefs?.targetLang === "fr" || prefs?.targetLang === "de" || prefs?.targetLang === "es" ? prefs.targetLang : "en";
  const targetVoice = targetLang === "en" ? enVoice : pickTargetVoice(prefs, targetLang);
  return { enVoice, enVoiceMale, arVoice, targetVoice };
}


// ---------- Local audio (10-sentence test pack) ----------
// These files are bundled inside the Android app. For the 10 test sentences,
// local MP3 playback is preferred over SpeechSynthesis. Other sentences keep
// the existing TTS fallback until the full audio pack is added.
const LOCAL_AUDIO_BY_EN = new Map([
  ["I can't believe how fast this year is going.", "001"],
  ["Have you tried that new coffee place downtown?", "002"],
  ["I've been so busy lately, it's crazy.", "003"],
  ["Isn't it supposed to rain later?", "004"],
  ["Same old, same old, you know how it is.", "005"],
  ["This week has just flown by.", "006"],
  ["I heard it's going to be sunny tomorrow.", "007"],
  ["Work has been keeping me on my toes.", "008"],
  ["I finally caught up on some sleep.", "009"],
  ["Can I get a table for two, please?", "010"],
]);

function localAudioPath(text, code, settings) {
  const id = LOCAL_AUDIO_BY_EN.get(text);
  if (!id) return null;
  if (code === "ar") return `./audio/arabic/${id}.mp3`;
  if (code === "target" && (settings.targetLang || "en") === "en") {
    const voice = settings.enVoiceURI === "local:puck" ? "puck" : "aoede";
    return `./audio/${voice}/${id}.mp3`;
  }
  return null;
}

function speakOnce(text, voice, rate, lang, onBoundary) {
  return new Promise((resolve) => {
    if (!window.speechSynthesis || !text) return resolve();
    const u = new SpeechSynthesisUtterance(text);
    if (voice) u.voice = voice;
    u.lang = voice ? voice.lang : lang;
    u.rate = rate;
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(); } };
    u.onend = finish;
    u.onerror = finish;
    if (onBoundary) {
      u.onboundary = (e) => {
        if (e.name && e.name !== "word") return;
        const start = e.charIndex;
        let end = text.indexOf(" ", start);
        if (end === -1) end = text.length;
        onBoundary({ start, end });
      };
    }
    window.speechSynthesis.speak(u);
    // Safety timeout: some mobile browsers silently drop utterances instead
    // of firing onend/onerror. Without this the whole queue would freeze
    // forever on one sentence — this is what caused "playback just stops".
    const safetyMs = Math.max(1800, (text.length * 130) / rate) + 4000;
    setTimeout(finish, safetyMs);
  });
}

function sleep(ms, isCurrent) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const tick = () => {
      if (!isCurrent() || Date.now() - t0 >= ms) return resolve();
      setTimeout(tick, 100);
    };
    tick();
  });
}


function playLocalOnce(src, rate, onBoundary) {
  return new Promise((resolve) => {
    const audio = new Audio(src);
    audio.preload = "auto";
    audio.playbackRate = Number(rate) || 1;
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(); } };
    audio.onended = finish;
    audio.onerror = finish;
    audio.ontimeupdate = () => {
      // Local MP3 files do not expose word boundaries; the UI therefore
      // clears the highlight while the audio is playing.
      if (onBoundary) onBoundary(null);
    };
    Player._audioEl = audio;
    audio.play().catch(finish);
  });
}

export const Player = {
  _getSettings: null,
  _onUpdate: null,
  _token: 0,
  _queue: [],
  _pos: 0,
  _state: "idle", // idle | playing | paused
  _repeatLabel: "",
  _highlight: null,
  _repeatMode: "all", // "off" | "all" | "one" — cycles via toggleRepeatMode()
  _silentLoopEl: null,
  _audioEl: null,

  init(getSettings, onUpdate) {
    this._getSettings = getSettings;
    this._onUpdate = onUpdate;
    // Silent background-friendly loop: helps Android keep the tab alive
    // while paired with the Media Session API. Not a guarantee (iOS Safari
    // suspends JS in the background regardless — that's an OS-level limit,
    // no website can override it), but it materially helps Android + desktop.
    try {
      const el = document.createElement("audio");
      el.loop = true;
      el.setAttribute("playsinline", "");
      el.volume = 0;
      // 1 second of silence, base64 WAV — tiny, no network fetch needed.
      el.src = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";
      this._silentLoopEl = el;
    } catch (e) {}
  },

  _snap() {
    return {
      queue: this._queue,
      pos: this._pos,
      state: this._state,
      repeatLabel: this._repeatLabel,
      highlight: this._highlight,
      repeatMode: this._repeatMode,
    };
  },
  _emit() {
    if (this._onUpdate) this._onUpdate(this._snap());
  },

  toggleRepeatMode() {
    this._repeatMode = this._repeatMode === "all" ? "one" : this._repeatMode === "one" ? "off" : "all";
    this._emit();
  },
  setRepeatMode(mode) {
    this._repeatMode = mode;
    this._emit();
  },

  playSingle(item) {
    this.start([item], 0, { forceSingleLoop: true });
  },

  start(queue, startPos = 0, opts = {}) {
    this._queue = queue;
    this._pos = startPos;
    if (opts.forceSingleLoop) this._repeatMode = "one";
    this._runLoop();
  },

  stop() {
    this._token++;
    window.speechSynthesis && window.speechSynthesis.cancel();
    if (this._audioEl) { try { this._audioEl.pause(); this._audioEl.currentTime = 0; } catch (e) {} }
    this._audioEl = null;
    this._queue = [];
    this._pos = 0;
    this._state = "idle";
    this._repeatLabel = "";
    this._highlight = null;
    if (this._silentLoopEl) { try { this._silentLoopEl.pause(); } catch (e) {} }
    this._emit();
  },

  pause() {
    if (this._state !== "playing") return;
    this._token++; // stops the active loop iteration cleanly
    window.speechSynthesis && window.speechSynthesis.cancel();
    if (this._audioEl) { try { this._audioEl.pause(); } catch (e) {} }
    this._state = "paused";
    this._emit();
  },

  resume() {
    if (this._state === "playing" || !this._queue.length) return;
    this._runLoop();
  },

  next() {
    if (!this._queue.length) return;
    this._token++;
    window.speechSynthesis && window.speechSynthesis.cancel();
    if (this._audioEl) { try { this._audioEl.pause(); } catch (e) {} }
    this._pos = (this._pos + 1) % this._queue.length;
    this._runLoop();
  },

  prev() {
    if (!this._queue.length) return;
    this._token++;
    window.speechSynthesis && window.speechSynthesis.cancel();
    if (this._audioEl) { try { this._audioEl.pause(); } catch (e) {} }
    this._pos = (this._pos - 1 + this._queue.length) % this._queue.length;
    this._runLoop();
  },

  // Called when the rate slider moves during active playback: restart the
  // current sentence's current utterance immediately at the new rate rather
  // than waiting for the next sentence, so the change is heard right away.
  restartWithNewRate() {
    if (this._state !== "playing") return;
    this._token++;
    window.speechSynthesis && window.speechSynthesis.cancel();
    if (this._audioEl) { try { this._audioEl.pause(); } catch (e) {} }
    this._runLoop();
  },

  async _runLoop() {
    const myToken = ++this._token;
    const isCurrent = () => this._token === myToken;
    this._state = "playing";
    if (this._silentLoopEl) { try { await this._silentLoopEl.play(); } catch (e) {} }
    this._emit();

    while (isCurrent()) {
      const settings = this._getSettings ? this._getSettings() : {};
      const item = this._queue[this._pos];
      if (!item) { this.stop(); return; }

      const { arVoice, targetVoice } = pickVoices(settings);
      const rate = settings.rate || 1;
      const enRepeat = Math.max(1, settings.enRepeat || 1);
      const arRepeat = Math.max(0, settings.arRepeat ?? 1);
      const gapMs = Math.max(0, (settings.gapSeconds ?? 1.2) * 1000);
      const startLang = settings.startLang || "target";
      const [, ar] = item.sentence;
      const targetLang = ["fr", "de", "es"].includes(settings.targetLang) ? settings.targetLang : "en";
      const targetTextValue = targetText(item.sentence, targetLang);
      const targetSpeechLang = { en: "en-US", fr: "fr-FR", de: "de-DE", es: "es-ES" }[targetLang];
      const targetLabel = targetLang.toUpperCase();

      const langs = startLang === "ar"
        ? [{ code: "ar", label: "AR", text: ar, voice: arVoice, times: arRepeat, speechLang: "ar-SA" },
           { code: "target", label: targetLabel, text: targetTextValue, voice: targetVoice, times: enRepeat, speechLang: targetSpeechLang }]
        : [{ code: "target", label: targetLabel, text: targetTextValue, voice: targetVoice, times: enRepeat, speechLang: targetSpeechLang },
           { code: "ar", label: "AR", text: ar, voice: arVoice, times: arRepeat, speechLang: "ar-SA" }];

      for (const lang of langs) {
        if (!isCurrent()) return;
        for (let rep = 1; rep <= lang.times; rep++) {
          if (!isCurrent()) return;
          this._repeatLabel = `${lang.label} ${rep}/${lang.times}`;
          this._highlight = null;
          this._emit();
          const localSrc = localAudioPath(lang.text, lang.code, settings);
          if (localSrc) {
            await playLocalOnce(
              localSrc,
              rate,
              lang.code === "target" ? (b) => { if (isCurrent()) { this._highlight = b; this._emit(); } } : null
            );
          } else {
            await speakOnce(lang.text, lang.voice, rate, lang.speechLang,
              lang.code === "target" ? (b) => { if (isCurrent()) { this._highlight = b; this._emit(); } } : null);
          }
          if (!isCurrent()) return;
          this._highlight = null;
          if (rep < lang.times || lang !== langs[langs.length - 1]) {
            await sleep(gapMs, isCurrent);
          }
        }
      }
      if (!isCurrent()) return;
      this._repeatLabel = "";
      this._emit();

      // one sentence complete
      if (settings.onSentenceComplete) settings.onSentenceComplete(item);

      if (this._repeatMode === "one") {
        await sleep(gapMs, isCurrent);
        continue; // repeat same sentence
      }

      const atEnd = this._pos >= this._queue.length - 1;
      if (atEnd) {
        if (this._repeatMode === "all") {
          this._pos = 0;
          await sleep(gapMs, isCurrent);
          continue;
        } else {
          this.stop();
          return;
        }
      } else {
        this._pos += 1;
        this._emit();
        await sleep(gapMs, isCurrent);
        continue;
      }
    }
  },
};

// ---------- Pronunciation check (Web Speech Recognition) ----------
// Feature-detected: Chrome/Edge/Safari on a real device expose this (it needs
// mic permission and, on most browsers, an internet connection since the
// recognition itself runs in the cloud — same as any other speech-to-text
// keyboard dictation feature). We degrade gracefully everywhere else.
const SpeechRecognitionCtor = typeof window !== "undefined" ? (window.SpeechRecognition || window.webkitSpeechRecognition) : null;

export function pronunciationSupported() {
  return !!SpeechRecognitionCtor;
}

// Aligns the words the user actually said against the target sentence using
// a simple LCS (longest common subsequence) over normalized word tokens, so
// a skipped/extra/mispronounced-and-misheard word doesn't throw off every
// word after it — only the words that truly don't line up are marked wrong.
function normWord(w) {
  return w.toLowerCase().replace(/[^\p{L}\p{N}']/gu, "");
}
export function scorePronunciation(target, said) {
  const t = target.split(/\s+/).filter(Boolean);
  const s = said.split(/\s+/).filter(Boolean);
  const tn = t.map(normWord);
  const sn = s.map(normWord);
  const n = tn.length, m = sn.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      dp[i][j] = tn[i - 1] && tn[i - 1] === sn[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }
  const matched = new Array(n).fill(false);
  let i = n, j = m;
  while (i > 0 && j > 0) {
    if (tn[i - 1] === sn[j - 1]) { matched[i - 1] = true; i--; j--; }
    else if (dp[i - 1][j] >= dp[i][j - 1]) i--;
    else j--;
  }
  const tokens = t.map((w, idx) => ({ word: w, ok: matched[idx] }));
  const score = n ? Math.round((dp[n][m] / n) * 100) : 0;
  return { score, tokens };
}

export const PronunciationCheck = {
  _recognition: null,
  // onInterim fires with live partial text *while the person is still
  // talking* — this is the visible proof-of-life that the mic is actually
  // being heard. Without it, a student who mumbles or pauses too long sees
  // nothing happen and (reasonably) assumes the mic is broken, when really
  // recognition just hasn't finalized a phrase yet.
  start(lang, { onResult, onInterim, onError, onEnd }) {
    if (!SpeechRecognitionCtor) { onError && onError("unsupported"); return; }
    try {
      const rec = new SpeechRecognitionCtor();
      rec.lang = lang || "en-US";
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      let gotAnySound = false;
      rec.onresult = (e) => {
        gotAnySound = true;
        let finalText = "", interimText = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const t = e.results[i][0].transcript;
          if (e.results[i].isFinal) finalText += t; else interimText += t;
        }
        if (interimText) onInterim && onInterim(interimText);
        if (finalText) onResult && onResult(finalText);
      };
      // Chrome fires this the instant it detects the mic is picking up any
      // sound at all (before it even attempts to recognize words) — used to
      // flip the UI from "استمع..." to a confirmed "سامعينك..." state.
      rec.onspeechstart = () => { gotAnySound = true; onInterim && onInterim(""); };
      rec.onerror = (e) => onError && onError(e.error || "error");
      rec.onend = () => onEnd && onEnd(gotAnySound);
      this._recognition = rec;
      rec.start();
    } catch (e) {
      onError && onError("error");
    }
  },
  stop() {
    try { this._recognition && this._recognition.stop(); } catch (e) {}
  },
};
